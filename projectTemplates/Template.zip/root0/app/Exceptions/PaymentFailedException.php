<?php
/**
 * Created by IntelliJ IDEA.
 * User: QZD2D0
 * Date: 1/9/2017
 * Time: 12:53 PM
 */
namespace App\Exceptions;

class PaymentFailedException extends \Exception
{
    //
}
