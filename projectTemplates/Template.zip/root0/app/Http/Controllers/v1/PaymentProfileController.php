<?php
/**
 * Created by IntelliJ IDEA.
 * User: QZD2D0
 * Date: 1/6/2017
 * Time: 5:26 PM
 */
namespace App\Http\Controllers\v1;

use App\Http\Controllers\Controller;
use App\PaymentProfile;
use App\PaymentProvider;
use GM\UAS\Core\Envelope\Http\Response;
use GM\UAS\Core\Envelope\Http\Validate;
use Illuminate\Http\Request;
use App\PaymentProcessor as Processor;
use GMLog;

/**
 * Class PaymentProfileController
 * @package App\Http\Controllers\v1
 */
class PaymentProfileController extends Controller
{
    /**
     * @var Response
     */
    protected \$response;

    /**
     * PaymentProfileController constructor.
     * @param Response \$response
     */
    public function __construct(Response \$response)
    {
        \$this->response = \$response;
    }

    /**
     * @param Request \$request
     * @return \Illuminate\Http\Response
     */
    public function index(Request \$request)
    {
        \$rules = [
            'user' => 'object_id',
        ];
        if ((\$response = Validate::validate(\$this->response, \$request->all(), \$rules)) !== true) {
            return \$response;
        }

        \$q = PaymentProfile::query();
        if (\$request->get('user')) {
            \$q->where('user_guid', '=', \$request->get('user')['id']);
        }
        return \$this->response->index(\$q->get());
    }

    /**
     * @param \$id
     * @return bool|\Illuminate\Http\Response
     */
    public function show(\$id)
    {
        \$rules = [
            'id' => 'required|alpha_dash|size:36',
        ];
        if ((\$response = Validate::validate(\$this->response, ['id' => \$id], \$rules)) !== true) {
            return \$response;
        }

        /** @var PaymentProfile \$profile */
        \$profile = PaymentProfile::query()->where('guid', '=', \$id)->first();

        return \$this->response->show(\$profile);
    }

    /**
     * @param Request \$request
     * @return bool|\Illuminate\Http\Response
     */
    public function store(Request \$request)
    {
        \$rules = [
            'provider' => 'required|object_id|exists:payment_provider,guid',
            'user' => 'required|object_id',
            'token' => 'required|alpha_dash',
            'bin' => 'string|size:6',
            'last4' => 'required|string|size:4',
            'exp_month' => 'integer|min:1|max:12',
            'exp_year' => 'integer|min:2000|max:3000',
            'card_brand' => 'string',
            'avs_response' => 'string',
            'default' => 'boolean',
        ];
        if ((\$response = Validate::validate(\$this->response, \$request->all(), \$rules)) !== true) {
            return \$response;
        }

        /** @var PaymentProvider \$provider */
        \$provider = PaymentProvider::query()->where('guid', '=', \$request->get('provider')['id'])->first();
        if (\$provider === null) {
            \$this->response->addCode(-1, 'Invalid provider id');
            return \$this->response->badRequest();
        }

        \$profile = new PaymentProfile([
            'guid' => createGUID(),
            'payment_provider_id' => \$provider->id,
            'user_guid' => \$request->get('user')['id'],
            'token' => \$request->get('token'),
            'bin' => \$request->get('bin'),
            'last4' => \$request->get('last4'),
            'exp_month' => str_pad(\$request->get('exp_month'), 2, '0', STR_PAD_LEFT),
            'exp_year' => \$request->get('exp_year'),
            'card_brand' => \$request->get('card_brand'),
            'avs_response' => \$request->get('avs_response'),
            'default' => \$request->get('default') ? 1 : 0,
        ]);
        try {
            \$profile->save();
        } catch (\Exception \$e) {
            GMLog::error(\$e->getMessage());
            return \$this->response->internalError();
        }

        if (\$profile->default) {
            PaymentProfile::query()->where('default', '=', true)
                ->where('user_guid', '=', \$profile->user_guid)
                ->where('id', '!=', \$profile->id)
                ->update(['default' => false]);
        }

        return \$this->response->created(\$profile);
    }

    /**
     * @param Request \$request
     * @param \$id
     * @return bool|\Illuminate\Http\Response
     */
    public function update(Request \$request, \$id)
    {
        \$rules = [
            'provider' => 'required|object_id|exists:payment_provider,guid',
            'user' => 'required|object_id',
            'token' => 'required|alpha_dash',
            'bin' => 'string|size:6',
            'last4' => 'required|string|size:4',
            'exp_month' => 'integer|min:1|max:12',
            'exp_year' => 'integer|min:2000|max:3000',
            'card_brand' => 'string',
            'default' => 'boolean',
        ];
        if ((\$response = Validate::validate(\$this->response, \$request->all(), \$rules)) !== true) {
            return \$response;
        }

        /** @var Processor \$provider */
        \$provider = PaymentProvider::query()->where('guid', '=', \$request->get('provider')['id'])->first();
        if (\$provider === null) {
            \$this->response->addCode(-1, 'Invalid provider id');
            return \$this->response->badRequest();
        }

        /** @var PaymentProfile \$profile */
        \$profile = PaymentProfile::query()->where('guid', '=', \$id)->first();
        if (\$profile === null) {
            return \$this->response->notFoundError();
        }
        \$profile->update([
            'payment_provider_id' => \$provider->id,
            'user_guid' => \$request->get('user')['id'],
            'token' => \$request->get('token'),
            'bin' => \$request->get('bin'),
            'last4' => \$request->get('last4'),
            'exp_month' => str_pad(\$request->get('exp_month'), 2, '0', STR_PAD_LEFT),
            'exp_year' => \$request->get('exp_year'),
            'card_brand' => \$request->get('card_brand'),
            'default' => \$request->get('default') ? 1 : 0,
        ]);
        try {
            \$profile->save();
        } catch (\Exception \$e) {
            GMLog::error(\$e->getMessage());
            \$this->response->internalError();
        }

        if (\$profile->default) {
            PaymentProfile::query()->where('default', '=', true)
                ->where('user_guid', '=', \$profile->user_guid)
                ->where('id', '!=', \$profile->id)
                ->update(['default' => false]);
        }

        return \$this->response->updated(\$profile);
    }
}
