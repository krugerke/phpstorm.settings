<?php

namespace App\Http\Controllers\v1;

use App\Http\Controllers\Controller;
use GM\UAS\Core\Envelope\Http\Response;
use GM\UAS\Core\Envelope\Http\Validate;
use Illuminate\Http\Request;
use App\PaymentProvider as Provider;

/**
 * Class PaymentProviderController
 * @package App\Http\Controllers\v1
 */
class PaymentProviderController extends Controller
{
    /**
     * @var Response
     */
    protected \$response;

    /**
     * PaymentProviderController constructor.
     * @param Response \$response
     */
    public function __construct(Response \$response)
    {
        \$this->response = \$response;
    }

    /**
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        \$all = Provider::all();

        return \$this->response->index(\$all);
    }

    /**
     * @param \$id
     * @return bool|\Illuminate\Http\Response
     */
    public function show(\$id)
    {
        \$rules = [
            'id' => 'required|alpha_dash|size:36',
        ];

        if ((\$response = Validate::validate(\$this->response, ['id' => \$id], \$rules)) !== true) {
            return \$response;
        }

        /** @var Provider \$provider */
        \$provider = Provider::query()->where('guid', '=', \$id)->first();

        if (\$provider === null) {
            return \$this->response->notFoundError();
        }

        return \$this->response->show(\$provider);
    }
}
