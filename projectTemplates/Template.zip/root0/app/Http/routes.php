<?php


/**
 * @SWG\Swagger(
 *   host="gm-uas-services-billingandpayment-payment.gm.com:8000",
 *   schemes={"http"},
 *   produces={"application/json"},
 *   consumes={"application/json"},
 *   basePath="/api",
 *   @SWG\Info(
 *     version="1.0.0",
 *     title="gm-uas-services-billingandpayment-payment",
 *   ),
 *   @SWG\Definition(
 *     definition="ObjectId",
 *     required={"id"},
 *     @SWG\Property(
 *       property="id",
 *       type="string",
 *       pattern="/^[0-9A-F]{8}-[0-9A-F]{4}-[0-9A-F]{4}-[0-9A-F]{4}-[0-9A-F]{12}\$/i",
 *     ),
 *   ),
 *   @SWG\Definition(
 *     definition="ObjectIdAny",
 *     required={"id"},
 *     @SWG\Property(
 *       property="id",
 *       type="string",
 *     ),
 *   ),
 *   @SWG\Definition(
 *     definition="DateTime",
 *     required={"date", "timezone_type", "timezone"},
 *     @SWG\Property(
 *       property="date",
 *       type="string",
 *       pattern="^[0-9]{4}-[0-9]{2}-[0-9]{2} [0-9]{2}:[0-9]{2}:[0-9]{2}.[0-9]{6}\$"
 *     ),
 *     @SWG\Property(
 *       property="timezone_type",
 *       type="integer"
 *     ),
 *     @SWG\Property(
 *       property="timezone",
 *       type="string"
 *     ),
 *   ),
 *   @SWG\Definition(
 *     definition="PaymentProviders",
 *     type="array",
 *     @SWG\Items(ref="\#/definitions/PaymentProvider")
 *   ),
 *   @SWG\Definition(
 *     definition="PaymentProcessors",
 *     type="array",
 *     @SWG\Items(ref="\#/definitions/PaymentProcessor")
 *   ),
 *   @SWG\Definition(
 *     definition="PaymentChannels",
 *     type="array",
 *     @SWG\Items(ref="\#/definitions/PaymentChannel")
 *   ),
 *   @SWG\Definition(
 *     definition="PaymentProfiles",
 *     type="array",
 *     @SWG\Items(ref="\#/definitions/PaymentProfile")
 *   ),
 *   @SWG\Definition(
 *     definition="Transactions",
 *     type="array",
 *     @SWG\Items(ref="\#/definitions/Transaction")
 *   ),
 * )
 */


/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It is a breeze. Simply tell Lumen the URIs it should respond to
| and give it the Closure to call when that URI is requested.
|
*/

\$app->get('/', function () use (\$app) {
    //return \$app->version();
    return 'This is not the page you are looking for';
});

\$app->group(
    [
        'namespace' => 'App\Http\Controllers\v1',
        'prefix' => 'api/v1',
        'middleware' => [
            \GM\UAS\Core\Authenticate\Middleware\RefreshToken::class,
            \GM\UAS\Core\Authenticate\Middleware\AuthToken::class,
        ],
    ],
    function () use (\$app) {

        /**
         * @SWG\Get(path="/api/v1/payment/provider",
         *   summary="View all providers",
         *   operationId="PaymentProviderController@index",
         *   produces={"application/json"},
         *   @SWG\Response(
         *      response="200",
         *      description="Return a list of payment providers",
         *     schema=@SWG\Schema(ref="\#/definitions/PaymentProviders")
         *   ),
         *   @SWG\Response(
         *      response="404",
         *      description="Provider not found"
         * )
         * )
         */
        \$app->get('payment/provider', 'PaymentProviderController@index');
        /**
         * @SWG\Get(path="/api/v1/payment/provider/{id}",
         *   summary="View a particular Provider",
         *   operationId="PaymentProviderController@show",
         *   produces={"application/json"},
         *   @SWG\Response(
         *     response="200",
         *     description="Return a payment provider",
         *     schema=@SWG\Schema(ref="\#/definitions/PaymentProvider")
         *   ),
         *   @SWG\Response(
         *      response="404",
         *      description="Provider not found"),
         *   @SWG\Parameter(
         *     in="path",
         *     name="id",
         *     description="The guid of a particular provider",
         *     required=true,
         *     type="string",
         *   )
         * )
         */
        \$app->get('payment/provider/{id}', 'PaymentProviderController@show');

        /**
         * @SWG\Get(path="/api/v1/payment/processor",
         *   summary="View all processors",
         *   operationId="PaymentProcessorController@index",
         *   produces={"application/json"},
         *   @SWG\Response(
         *     response="200",
         *     description="Return a list of payment processors",
         *     schema=@SWG\Schema(ref="\#/definitions/PaymentProcessors")
         *   ),
         *   @SWG\Response(
         *      response="404",
         *      description="Provider not found"
         *   )
         * )
         */
        \$app->get('payment/processor', 'PaymentProcessorController@index');

        /**
         * @SWG\Get(path="/api/v1/payment/processor/{id}",
         *   summary="View a particular processor",
         *   operationId="PaymentProcessorController@show",
         *   produces={"application/json"},
         *   @SWG\Response(
         *      response="200",
         *      description="Return a payment processor",
         *     schema=@SWG\Schema(ref="\#/definitions/PaymentProcessor")
         *   ),
         *   @SWG\Response(
         *      response="404",
         *      description="Processor not found"),
         *   @SWG\Parameter(
         *     in="path",
         *     name="id",
         *     description="The guid of a particular processor",
         *     required=true,
         *     type="string",
         *   )
         * )
         */
        \$app->get('payment/processor/{id}', 'PaymentProcessorController@show');

        /**
         * @SWG\Post(
         *   path="/api/v1/payment/processor",
         *   summary="View a particular processor",
         *   operationId="PaymentProcessorController@store",
         *   produces={"application/json"},
         *   consumes={"application/json"},
         *   @SWG\Response(
         *     response="201",
         *     description="Return a payment processor",
         *     schema=@SWG\Schema(ref="\#/definitions/PaymentProcessor")
         *   ),
         *   @SWG\Response(
         *      response="400",
         *      description="Bad request"
         *   ),
         *   @SWG\Parameter(
         *     in="body",
         *     name="processor",
         *     required=true,
         *     @SWG\Schema(
         *       @SWG\Property(
         *         property="name",
         *         description="Name of the processor account",
         *         type="string",
         *         format="string"
         *       ),
         *       @SWG\Property(
         *         property="provider",
         *         type="object",
         *         description="Payment Provider",
         *         @SWG\Property(
         *           property="id",
         *           type="string",
         *           pattern="/^[0-9A-F]{8}-[0-9A-F]{4}-[0-9A-F]{4}-[0-9A-F]{4}-[0-9A-F]{12}\$/i"
         *         )
         *       ),
         *       @SWG\Property(
         *         property="username",
         *         description="Processor account username",
         *         type="string"
         *       ),
         *       @SWG\Property(
         *         property="password",
         *         description="Processor account password",
         *         type="string",
         *         format="password"
         *       ),
         *       @SWG\Property(
         *         property="sandbox",
         *         description="Is this account a sandbox/test account",
         *         type="boolean"
         *       ),
         *       @SWG\Property(
         *         property="status",
         *         type="integer",
         *         description="Processor account status"
         *       )
         *     )
         *   )
         * )
         */
        \$app->post('payment/processor', 'PaymentProcessorController@store');

        /**
         * @SWG\Put(
         *   path="/api/v1/payment/processor/{id}",
         *   summary="Update a particular processor",
         *   operationId="PaymentProcessorController@update",
         *   produces={"application/json"},
         *   @SWG\Response(
         *     response="200",
         *     description="Return a payment processor",
         *     schema=@SWG\Schema(ref="\#/definitions/PaymentProcessor")
         *   ),
         *   @SWG\Response(
         *      response="404",
         *      description="Processor not found"
         *   ),
         *   @SWG\Parameter(
         *     in="path",
         *     name="id",
         *     description="The guid of a particular processor",
         *     required=true,
         *     type="string",
         *   ),
         *   @SWG\Parameter(
         *     in="body",
         *     name="processor",
         *     required=true,
         *     @SWG\Schema(
         *       @SWG\Property(
         *         property="name",
         *         description="Name of the processor account",
         *         type="string",
         *         format="string"
         *       ),
         *       @SWG\Property(
         *         property="provider",
         *         type="object",
         *         description="Payment Provider",
         *         @SWG\Property(
         *           property="id",
         *           type="string",
         *           pattern="/^[0-9A-F]{8}-[0-9A-F]{4}-[0-9A-F]{4}-[0-9A-F]{4}-[0-9A-F]{12}\$/i"
         *         )
         *       ),
         *       @SWG\Property(
         *         property="username",
         *         description="Processor account username",
         *         type="string"
         *       ),
         *       @SWG\Property(
         *         property="password",
         *         description="Processor account password",
         *         type="string",
         *         format="password"
         *       ),
         *       @SWG\Property(
         *         property="sandbox",
         *         description="Is this account a sandbox/test account",
         *         type="boolean"
         *       ),
         *       @SWG\Property(
         *         property="status",
         *         type="integer",
         *         description="Processor account status"
         *       )
         *     )
         *   )
         * )
         */
        \$app->put('payment/processor/{id}', 'PaymentProcessorController@update');
        \$app->patch('payment/processor/{id}', 'PaymentProcessorController@update');


        /**
         * @SWG\Post(
         *   path="/api/v1/payment/processor/{id}/currency",
         *   summary="Add a currency to processor",
         *   operationId="PaymentProcessorController@storeCurrency",
         *   produces={"application/json"},
         *   consumes={"application/json"},
         *   @SWG\Response(
         *     response="201",
         *     description="Success",
         *     schema=@SWG\Schema(ref="\#/definitions/PaymentProcessorCurrency")
         *   ),
         *   @SWG\Response(
         *      response="400",
         *      description="Bad request"
         *   ),
         *   @SWG\Parameter(
         *     in="path",
         *     name="id",
         *     description="The guid of a particular processor",
         *     required=true,
         *     type="string",
         *     pattern="/^[0-9A-F]{8}-[0-9A-F]{4}-[0-9A-F]{4}-[0-9A-F]{4}-[0-9A-F]{12}\$/i"
         *   ),
         *   @SWG\Parameter(
         *     in="body",
         *     name="currency",
         *     required=true,
         *     @SWG\Schema(
         *       @SWG\Property(
         *         property="iso_code",
         *         description="ISO3 currency code",
         *         type="string",
         *         format="string",
         *         maxLength=3,
         *         minLength=3,
         *         pattern="^[A-Z]{3}\$",
         *       )
         *     )
         *   )
         * )
         */
        \$app->post('payment/processor/{id}/currency', 'PaymentProcessorController@storeCurrency');
        /**
         * @SWG\Delete(
         *   path="/api/v1/payment/processor/{id}/currency",
         *   summary="Delete a currency from processor",
         *   operationId="PaymentProcessorController@destroyCurrency",
         *   produces={"application/json"},
         *   consumes={"application/json"},
         *   @SWG\Response(
         *     response="201",
         *     description="Success",
         *     schema=@SWG\Schema(ref="\#/definitions/PaymentProcessorCurrency")
         *   ),
         *   @SWG\Response(
         *      response="400",
         *      description="Bad request"
         *   ),
         *   @SWG\Parameter(
         *     in="path",
         *     name="id",
         *     description="The guid of a particular processor",
         *     required=true,
         *     type="string",
         *     pattern="/^[0-9A-F]{8}-[0-9A-F]{4}-[0-9A-F]{4}-[0-9A-F]{4}-[0-9A-F]{12}\$/i"
         *   ),
         *   @SWG\Parameter(
         *     in="body",
         *     name="currency",
         *     required=true,
         *     @SWG\Schema(
         *       @SWG\Property(
         *         property="iso_code",
         *         description="ISO3 currency code",
         *         type="string",
         *         format="string",
         *         maxLength=3,
         *         minLength=3,
         *         pattern="^[A-Z]{3}\$"
         *       )
         *     )
         *   )
         * )
         */
        \$app->delete('payment/processor/{id}/currency', 'PaymentProcessorController@destroyCurrency');

        /**
         * @SWG\Get(
         *     path="/api/v1/payment/processor/{pid}/channel",
         *     summary="List channels on a payment processor",
         *     operationId="PaymentChannelController@index",
         *     produces={"application/json"},
         *     consumes={"application/json"},
         *     @SWG\Response(
         *      response="200",
         *      description="Success",
         *      schema=@SWG\Schema(ref="\#/definitions/PaymentChannels")
         *     ),
         *     @SWG\Response(
         *      response="400",
         *      description="Bad Request",
         *     ),
         *     @SWG\Parameter(
         *      in="path",
         *      name="pid",
         *      description="Processor id",
         *      required=true,
         *      type="string",
         *       pattern="/^[0-9A-F]{8}-[0-9A-F]{4}-[0-9A-F]{4}-[0-9A-F]{4}-[0-9A-F]{12}\$/i"
         *     ),
         * )
         */
        \$app->get('payment/processor/{pid}/channel', 'PaymentChannelController@index');
        /**
         * @SWG\Get(
         *     path="/api/v1/payment/processor/{pid}/channel/{id}",
         *     summary="Show specific channel on a payment processor",
         *     operationId="PaymentChannelController@show",
         *     produces={"application/json"},
         *     consumes={"application/json"},
         *     @SWG\Response(
         *      response="200",
         *      description="Success",
         *      schema=@SWG\Schema(ref="\#/definitions/PaymentChannel")
         *     ),
         *     @SWG\Response(
         *      response="400",
         *      description="Bad Request",
         *     ),
         *     @SWG\Parameter(
         *      in="path",
         *      name="pid",
         *      description="Processor id",
         *      required=true,
         *      type="string",
         *       pattern="/^[0-9A-F]{8}-[0-9A-F]{4}-[0-9A-F]{4}-[0-9A-F]{4}-[0-9A-F]{12}\$/i"
         *     ),
         *     @SWG\Parameter(
         *      in="path",
         *      name="id",
         *      description="Channel id",
         *      required=true,
         *      type="string",
         *       pattern="/^[0-9A-F]{8}-[0-9A-F]{4}-[0-9A-F]{4}-[0-9A-F]{4}-[0-9A-F]{12}\$/i"
         *     ),
         * )
         */
        \$app->get('payment/processor/{pid}/channel/{id}', 'PaymentChannelController@show');
        /**
         * @SWG\Post(
         *     path="/api/v1/payment/processor/{pid}/channel",
         *     summary="Store new channel on processor",
         *     operationId="PaymentChannelController@store",
         *     produces={"application/json"},
         *     consumes={"application/json"},
         *     @SWG\Response(
         *      response="200",
         *      description="Success",
         *      schema=@SWG\Schema(ref="\#/definitions/PaymentChannel")
         *     ),
         *     @SWG\Response(
         *      response="400",
         *      description="Bad Request",
         *     ),
         *     @SWG\Parameter(
         *      in="path",
         *      name="pid",
         *      description="Processor id",
         *      required=true,
         *      type="string",
         *       pattern="/^[0-9A-F]{8}-[0-9A-F]{4}-[0-9A-F]{4}-[0-9A-F]{4}-[0-9A-F]{12}\$/i"
         *     ),
         *     @SWG\Parameter(
         *      in="body",
         *      name="channel",
         *      @SWG\Schema(
         *          @SWG\Property(
         *              property="name",
         *              type="string",
         *          ),
         *          @SWG\Property(
         *              property="channel",
         *              type="string",
         *          ),
         *          @SWG\Property(
         *              property="status",
         *              type="integer",
         *          ),
         *      ),
         *     ),
         * )
         */
        \$app->post('payment/processor/{pid}/channel', 'PaymentChannelController@store');
        /**
         * @SWG\Put(
         *     path="/api/v1/payment/processor/{pid}/channel/{id}",
         *     summary="Update channel on processor",
         *     operationId="PaymentChannelController@update",
         *     produces={"application/json"},
         *     consumes={"application/json"},
         *     @SWG\Response(
         *      response="200",
         *      description="Success",
         *      schema=@SWG\Schema(ref="\#/definitions/PaymentChannel")
         *     ),
         *     @SWG\Response(
         *      response="400",
         *      description="Bad Request",
         *     ),
         *     @SWG\Parameter(
         *      in="path",
         *      name="pid",
         *      description="Processor id",
         *      required=true,
         *      type="string",
         *       pattern="/^[0-9A-F]{8}-[0-9A-F]{4}-[0-9A-F]{4}-[0-9A-F]{4}-[0-9A-F]{12}\$/i"
         *     ),
         *     @SWG\Parameter(
         *      in="path",
         *      name="id",
         *      description="Channel id",
         *      required=true,
         *      type="string",
         *       pattern="/^[0-9A-F]{8}-[0-9A-F]{4}-[0-9A-F]{4}-[0-9A-F]{4}-[0-9A-F]{12}\$/i"
         *     ),
         *     @SWG\Parameter(
         *      in="body",
         *      name="channel",
         *      @SWG\Schema(
         *          @SWG\Property(
         *              property="name",
         *              type="string",
         *          ),
         *          @SWG\Property(
         *              property="channel",
         *              type="string",
         *          ),
         *          @SWG\Property(
         *              property="status",
         *              type="integer",
         *          ),
         *      ),
         *     ),
         * )
         */
        \$app->put('payment/processor/{pid}/channel/{id}', 'PaymentChannelController@update');
        \$app->patch('payment/processor/{pid}/channel/{id}', 'PaymentChannelController@update');

        /**
         * @SWG\Get(
         *     path="/api/v1/payment/profile",
         *     summary="List payment profiles",
         *     operationId="PaymentProfileController@index",
         *     produces={"application/json"},
         *     consumes={"application/json"},
         *     @SWG\Response(
         *      response="200",
         *      description="Success",
         *      schema=@SWG\Schema(ref="\#/definitions/PaymentProfiles")
         *     ),
         *     @SWG\Response(
         *      response="400",
         *      description="Bad Request",
         *     ),
         *     @SWG\Parameter(
         *      in="query",
         *      name="user[id]",
         *      description="User id",
         *      required=false,
         *      type="string",
         *       pattern="/^[0-9A-F]{8}-[0-9A-F]{4}-[0-9A-F]{4}-[0-9A-F]{4}-[0-9A-F]{12}\$/i"
         *     ),
         * )
         */
        \$app->get('payment/profile', 'PaymentProfileController@index');
        /**
         * @SWG\Get(
         *     path="/api/v1/payment/profile/{id}",
         *     summary="Show individual payment profile",
         *     operationId="PaymentProfileController@show",
         *     produces={"application/json"},
         *     consumes={"application/json"},
         *     @SWG\Response(
         *      response="200",
         *      description="Success",
         *      schema=@SWG\Schema(ref="\#/definitions/PaymentProfile")
         *     ),
         *     @SWG\Response(
         *      response="400",
         *      description="Bad Request",
         *     ),
         *     @SWG\Parameter(
         *      in="path",
         *      name="id",
         *      description="Profile id",
         *      required=true,
         *      type="string",
         *       pattern="/^[0-9A-F]{8}-[0-9A-F]{4}-[0-9A-F]{4}-[0-9A-F]{4}-[0-9A-F]{12}\$/i"
         *     ),
         * )
         */
        \$app->get('payment/profile/{id}', 'PaymentProfileController@show');
        /**
         * @SWG\Post(
         *     path="/api/v1/payment/profile",
         *     summary="Store payment profile",
         *     operationId="PaymentProfileController@store",
         *     produces={"application/json"},
         *     consumes={"application/json"},
         *     @SWG\Response(
         *      response="201",
         *      description="Success",
         *      schema=@SWG\Schema(ref="\#/definitions/PaymentProfile")
         *     ),
         *     @SWG\Response(
         *      response="400",
         *      description="Bad Request",
         *     ),
         *     @SWG\Parameter(
         *      in="body",
         *      name="profile",
         *      required=true,
         *      @SWG\Schema(
         *       @SWG\Property(
         *         property="provider",
         *         type="object",
         *         description="Payment Provider",
         *         @SWG\Property(
         *           property="id",
         *           type="string",
         *           pattern="/^[0-9A-F]{8}-[0-9A-F]{4}-[0-9A-F]{4}-[0-9A-F]{4}-[0-9A-F]{12}\$/i"
         *         ),
         *       ),
         *       @SWG\Property(
         *         property="user",
         *         type="object",
         *         description="User",
         *         @SWG\Property(
         *           property="id",
         *           type="string",
         *           pattern="/^[0-9A-F]{8}-[0-9A-F]{4}-[0-9A-F]{4}-[0-9A-F]{4}-[0-9A-F]{12}\$/i"
         *         )
         *       ),
         *       @SWG\Property(
         *         property="token",
         *         type="string",
         *       ),
         *       @SWG\Property(
         *         property="bin",
         *         type="string",
         *         minLength=6,
         *         maxLength=6,
         *       ),
         *       @SWG\Property(
         *         property="last4",
         *         type="string",
         *         minLength=4,
         *         maxLength=4,
         *       ),
         *       @SWG\Property(
         *         property="exp_month",
         *         type="string",
         *         minLength=2,
         *         maxLength=2,
         *       ),
         *       @SWG\Property(
         *         property="exp_year",
         *         type="string",
         *         minLength=4,
         *         maxLength=4,
         *       ),
         *       @SWG\Property(
         *         property="card_brand",
         *         type="string",
         *         minLength=2,
         *         maxLength=16,
         *       ),
         *       @SWG\Property(
         *         property="default",
         *         type="boolean",
         *       ),
         *      ),
         *     ),
         * )
         */
        \$app->post('payment/profile', 'PaymentProfileController@store');
        /**
         * @SWG\Put(
         *     path="/api/v1/payment/profile/{id}",
         *     summary="Update payment profile",
         *     operationId="PaymentProfileController@update",
         *     produces={"application/json"},
         *     consumes={"application/json"},
         *     @SWG\Response(
         *      response="200",
         *      description="Success",
         *      schema=@SWG\Schema(ref="\#/definitions/PaymentProfile")
         *     ),
         *     @SWG\Response(
         *      response="400",
         *      description="Bad Request",
         *     ),
         *     @SWG\Response(
         *      response="404",
         *      description="Not Found",
         *     ),
         *     @SWG\Parameter(
         *      in="path",
         *      name="id",
         *      required=true,
         *      type="string",
         *     ),
         *     @SWG\Parameter(
         *      in="body",
         *      name="profile",
         *      required=true,
         *      @SWG\Schema(
         *       @SWG\Property(
         *         property="provider",
         *         type="object",
         *         description="Payment Provider",
         *         @SWG\Property(
         *           property="id",
         *           type="string",
         *           pattern="/^[0-9A-F]{8}-[0-9A-F]{4}-[0-9A-F]{4}-[0-9A-F]{4}-[0-9A-F]{12}\$/i"
         *         )
         *       ),
         *       @SWG\Property(
         *         property="user",
         *         type="object",
         *         description="User",
         *         @SWG\Property(
         *           property="id",
         *           type="string",
         *           pattern="/^[0-9A-F]{8}-[0-9A-F]{4}-[0-9A-F]{4}-[0-9A-F]{4}-[0-9A-F]{12}\$/i"
         *         )
         *       ),
         *       @SWG\Property(
         *         property="token",
         *         type="string",
         *       ),
         *       @SWG\Property(
         *         property="bin",
         *         type="string",
         *         minLength=6,
         *         maxLength=6,
         *       ),
         *       @SWG\Property(
         *         property="last4",
         *         type="string",
         *         minLength=4,
         *         maxLength=4,
         *       ),
         *       @SWG\Property(
         *         property="exp_month",
         *         type="string",
         *         minLength=2,
         *         maxLength=2,
         *       ),
         *       @SWG\Property(
         *         property="exp_year",
         *         type="string",
         *         minLength=4,
         *         maxLength=4,
         *       ),
         *       @SWG\Property(
         *         property="card_brand",
         *         type="string",
         *         minLength=2,
         *         maxLength=16,
         *       ),
         *       @SWG\Property(
         *         property="default",
         *         type="boolean",
         *       ),
         *      ),
         *     ),
         * )
         */
        \$app->put('payment/profile/{id}', 'PaymentProfileController@update');
        \$app->patch('payment/profile/{id}', 'PaymentProfileController@update');

        /**
         * @SWG\Get(
         *     path="/api/v1/payment/transaction",
         *     summary="List transactions",
         *     operationId="TransactionController@index",
         *     produces={"application/json"},
         *     consumes={"application/json"},
         *     @SWG\Response(
         *      response="200",
         *      description="Success",
         *      schema=@SWG\Schema(ref="\#/definitions/Transactions")
         *     ),
         *     @SWG\Response(
         *      response="400",
         *      description="Bad Request",
         *     ),
         *     @SWG\Parameter(
         *      in="query",
         *      name="user[id]",
         *      description="User id",
         *      required=false,
         *      type="string",
         *       pattern="/^[0-9A-F]{8}-[0-9A-F]{4}-[0-9A-F]{4}-[0-9A-F]{4}-[0-9A-F]{12}\$/i"
         *     ),
         *     @SWG\Parameter(
         *      in="query",
         *      name="invoice[id]",
         *      description="Invoice id",
         *      required=false,
         *      type="string",
         *     ),
         *     @SWG\Parameter(
         *      in="query",
         *      name="reservation[id]",
         *      description="Invoice id",
         *      required=false,
         *      type="string",
         *     ),
         * )
         */
        \$app->get('payment/transaction', 'TransactionController@index');
        /**
         * @SWG\Get(
         *     path="/api/v1/payment/transaction/{id}",
         *     summary="Show transaction",
         *     operationId="TransactionController@show",
         *     produces={"application/json"},
         *     consumes={"application/json"},
         *     @SWG\Response(
         *      response="200",
         *      description="Success",
         *      schema=@SWG\Schema(ref="\#/definitions/Transaction")
         *     ),
         *     @SWG\Response(
         *      response="400",
         *      description="Bad Request",
         *     ),
         *     @SWG\Parameter(
         *      in="path",
         *      name="id",
         *      description="Transaction id",
         *      required=true,
         *      type="string",
         *      pattern="/^[0-9A-F]{8}-[0-9A-F]{4}-[0-9A-F]{4}-[0-9A-F]{4}-[0-9A-F]{12}\$/i"
         *     ),
         * )
         */
        \$app->get('payment/transaction/{id}', 'TransactionController@show');
        /**
         * @SWG\Post(
         *     path="/api/v1/payment/transaction",
         *     summary="Create transaction",
         *     operationId="TransactionController@store",
         *     produces={"application/json"},
         *     consumes={"application/json"},
         *     @SWG\Response(
         *      response="200",
         *      description="Success",
         *      schema=@SWG\Schema(ref="\#/definitions/Transaction")
         *     ),
         *     @SWG\Response(
         *      response="400",
         *      description="Bad Request",
         *     ),
         *     @SWG\Parameter(
         *      in="body",
         *      name="profile",
         *      required=true,
         *      @SWG\Schema(
         *       @SWG\Property(
         *         property="profile",
         *         type="object",
         *         description="Payment Profile",
         *         @SWG\Property(
         *           property="id",
         *           type="string",
         *           pattern="/^[0-9A-F]{8}-[0-9A-F]{4}-[0-9A-F]{4}-[0-9A-F]{4}-[0-9A-F]{12}\$/i"
         *         )
         *       ),
         *       @SWG\Property(
         *         property="user",
         *         type="object",
         *         description="User",
         *         @SWG\Property(
         *           property="id",
         *           type="string",
         *           pattern="/^[0-9A-F]{8}-[0-9A-F]{4}-[0-9A-F]{4}-[0-9A-F]{4}-[0-9A-F]{12}\$/i"
         *         ),
         *         @SWG\Property(
         *           property="first_name",
         *           type="string",
         *         ),
         *         @SWG\Property(
         *           property="last_name",
         *           type="string",
         *         ),
         *         @SWG\Property(
         *           property="mobile",
         *           type="string",
         *         ),
         *         @SWG\Property(
         *           property="email",
         *           type="string",
         *         ),
         *         @SWG\Property(
         *           property="birth_date",
         *           type="string",
         *         ),
         *         @SWG\Property(
         *           property="time_on_file",
         *           type="string",
         *         ),
         *         @SWG\Property(
         *           property="driver_license",
         *           type="string",
         *         ),
         *       ),
         *       @SWG\Property(
         *         property="invoice",
         *         type="object",
         *         description="Invoice",
         *         @SWG\Property(
         *           property="id",
         *           type="string",
         *         ),
         *       ),
         *       @SWG\Property(
         *         property="related_transaction",
         *         type="object",
         *         description="Related Transaction",
         *         @SWG\Property(
         *           property="id",
         *           type="string",
         *           pattern="/^[0-9A-F]{8}-[0-9A-F]{4}-[0-9A-F]{4}-[0-9A-F]{4}-[0-9A-F]{12}\$/i"
         *         ),
         *       ),
         *       @SWG\Property(
         *         property="reservation",
         *         type="object",
         *         description="Reservation",
         *         @SWG\Property(
         *           property="id",
         *           type="string",
         *           pattern="/^[0-9A-F]{8}-[0-9A-F]{4}-[0-9A-F]{4}-[0-9A-F]{4}-[0-9A-F]{12}\$/i"
         *         ),
         *         @SWG\Property(
         *           property="pickup_datetime",
         *           type="string",
         *         ),
         *         @SWG\Property(
         *           property="dropoff_datetime",
         *           type="string",
         *         ),
         *         @SWG\Property(
         *           property="pickup_location",
         *           type="string",
         *         ),
         *         @SWG\Property(
         *           property="dropoff_location",
         *           type="string",
         *         ),
         *       ),
         *       @SWG\Property(
         *         property="amount",
         *         type="integer",
         *       ),
         *       @SWG\Property(
         *         property="currency",
         *         type="string",
         *       ),
         *       @SWG\Property(
         *         property="descriptor",
         *         type="string",
         *       ),
         *       @SWG\Property(
         *         property="installments",
         *         type="string",
         *       ),
         *       @SWG\Property(
         *         property="type",
         *         type="string",
         *         enum={"auth","cap","authcap","credit","refund","void"},
         *       ),
         *      ),
         *     ),
         * )
         */
        \$app->post('payment/transaction', 'TransactionController@store');

        /**
         * @SWG\Post(
         *     path="/api/v1/payment/profilescript",
         *     summary="Request payment profile script",
         *     operationId="ProfileScriptController@store",
         *     produces={"application/json"},
         *     consumes={"application/json"},
         *     @SWG\Response(
         *      response="200",
         *      description="Success",
         *      schema=@SWG\Schema(ref="\#/definitions/ProfileScript")
         *     ),
         *     @SWG\Response(
         *      response="400",
         *      description="Bad Request",
         *     ),
         *     @SWG\Parameter(
         *      in="body",
         *      name="profile",
         *      required=true,
         *      @SWG\Schema(
         *       @SWG\Property(
         *         property="payment_channel",
         *         type="object",
         *         description="Payment channel",
         *         @SWG\Property(
         *           property="id",
         *           type="string",
         *           pattern="/^[0-9A-F]{8}-[0-9A-F]{4}-[0-9A-F]{4}-[0-9A-F]{4}-[0-9A-F]{12}\$/i"
         *         ),
         *       ),
         *       @SWG\Property(
         *         property="processor",
         *         type="object",
         *         description="Payment processor",
         *         @SWG\Property(
         *           property="id",
         *           type="string",
         *           pattern="/^[0-9A-F]{8}-[0-9A-F]{4}-[0-9A-F]{4}-[0-9A-F]{4}-[0-9A-F]{12}\$/i"
         *         ),
         *       ),
         *       @SWG\Property(
         *         property="user",
         *         type="object",
         *         description="User information",
         *         @SWG\Property(
         *           property="id",
         *           type="string",
         *           pattern="/^[0-9A-F]{8}-[0-9A-F]{4}-[0-9A-F]{4}-[0-9A-F]{4}-[0-9A-F]{12}\$/i"
         *         ),
         *         @SWG\Property(
         *           property="mobile",
         *           type="string",
         *         ),
         *         @SWG\Property(
         *           property="email",
         *           type="string",
         *         ),
         *         @SWG\Property(
         *           property="first_name",
         *           type="string",
         *         ),
         *         @SWG\Property(
         *           property="last_name",
         *           type="string",
         *         ),
         *         @SWG\Property(
         *           property="birth_date",
         *           type="string",
         *         ),
         *         @SWG\Property(
         *           property="time_on_file",
         *           type="string",
         *         ),
         *         @SWG\Property(
         *           property="driver_license",
         *           type="string",
         *         ),
         *       ),
         *      ),
         *     ),
         *  )
         */
        \$app->post('payment/profilescript', 'ProfileScriptController@store');
        /**
         * @SWG\Get(
         *   path="/api/v1/payment/profilescript/{id}/status",
         *   summary="Check status",
         *   operationId="ProfileScriptController@status",
         *   produces={"application/json"},
         *   @SWG\Response(
         *      response="200",
         *      description="Return profile script status",
         *     schema=@SWG\Schema(ref="\#/definitions/ProfileScript")
         *   ),
         *   @SWG\Response(
         *      response="404",
         *      description="Script not found"
         *   ),
         *   @SWG\Parameter(
         *     name="id",
         *     in="path",
         *     description="Profile script id",
         *     type="string",
         *     required=true,
         *      pattern="/^[0-9A-F]{8}-[0-9A-F]{4}-[0-9A-F]{4}-[0-9A-F]{4}-[0-9A-F]{12}\$/i",
         *   ),
         * )
         */
        \$app->get('payment/profilescript/{id}/status', 'ProfileScriptController@status');
    }
);
