<?php

namespace App;

use GM\UAS\Core\Envelope\Contracts\Model\ModelObject;
use GM\UAS\Core\Encryption\EncryptedField;

/**
 * Class PaymentProcessor
 * @package App
 * @SWG\Definition(
 *     definition="PaymentProcessor",
 *     required={"id","name","provider","username","password","status"}
 * )
 */
class PaymentProcessor extends ModelObject
{
    /**
     *
     */
    const STATUS_INACTIVE = 0;
    /**
     *
     */
    const STATUS_ACTIVE = 1;

    /**
     * @return array
     */
    public static function getStatuses()
    {
        return [
            self::STATUS_INACTIVE,
            self::STATUS_ACTIVE,
        ];
    }

    /**
     * @var string
     */
    protected \$table = 'payment_processor';

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected \$fillable = [
        'id',
        'guid',
        'name',
        'payment_provider_id',
        'username',
        'password',
        'status',
        'sandbox',
        'created_at',
        'updated_at',
    ];

    /**
     * @return string
     */
    public function getUsername()
    {
        return EncryptedField::decrypt(\$this->username);
    }

    /**
     * @param \$username
     */
    public function setUsername(\$username)
    {
        \$this->username = EncryptedField::encrypt(\$username);
    }

    /**
     * @return string
     */
    public function getPassword()
    {
        return EncryptedField::decrypt(\$this->password);
    }

    /**
     * @param \$password
     */
    public function setPassword(\$password)
    {
        \$this->password = EncryptedField::encrypt(\$password);
    }

    /**
     * @SWG\Property(
     *   property="id", type="string", minLength=34, maxLength=34,
     *   pattern="^[0-9a-fA-F]{8}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{12}\$"
     * )
     * @SWG\Property(property="name", type="string")
     * @SWG\Property(property="provider", ref="\#/definitions/ObjectId")
     * @SWG\Property(property="username", type="string")
     * @SWG\Property(property="password", type="string")
     * @SWG\Property(property="status", type="integer")
     * @SWG\Property(property="sandbox", type="string")
     * @SWG\Property(property="created_at", ref="\#/definitions/DateTime"))
     * @SWG\Property(property="updated_at", ref="\#/definitions/DateTime"))
     * @return array
     */
    public function asData()
    {
        \$isoCodes = [];
        /** @var PaymentProcessorCurrency \$currency */
        foreach (\$this->getCurrencies() as \$currency) {
            \$isoCodes[] = \$currency->iso_code;
        }
        \$channels = [];
        /** @var PaymentChannel \$channel */
        foreach (\$this->getChannels() as \$channel) {
            \$channels[] = \$channel->asDataId();
        }
        \$return = [
            'id' => \$this->guid,
            'name' => \$this->name,
            'display_name' => \$this->getDisplayName(),
            'username' => \$this->getUsername(),
            'password' => \$this->getPassword(),
            'provider' => \$this->getProvider()->asDataId(),
            'sandbox' => \$this->sandbox,
            'status' => \$this->status,
            'supported_currency' => \$isoCodes,
            'channels' => \$channels,
            'created_at' => \$this->created_at,
            'updated_at' => \$this->updated_at,
        ];
        return \$return;
    }

    /**
     * @return string
     */
    public function getDisplayName()
    {
        return \$this->getProvider()->name . ' :: ' . \$this->name;
    }
    /**
     * @return \App\PaymentProvider
     */
    public function getProvider()
    {
        /** @var PaymentProvider \$provider */
        \$provider = \$this->hasOne(PaymentProvider::class, 'id', 'payment_provider_id')->getQuery()->first();
        return \$provider;
    }

    /**
     * @return PaymentProcessorCurrency[]
     */
    public function getCurrencies()
    {
        /** @var PaymentProcessorCurrency[] \$currencies */
        \$currencies = \$this->hasMany(PaymentProcessorCurrency::class, 'payment_processor_id', 'id')->getQuery()->get();
        return \$currencies;
    }

    /**
     * @return PaymentChannel[]
     */
    public function getChannels()
    {
        /** @var PaymentChannel[] \$channels */
        \$channels = \$this->hasMany(PaymentChannel::class, 'payment_processor_id', 'id')->getQuery()->get();
        return \$channels;
    }

    /**
     * @param string \$isoCode
     * @return bool
     */
    public function isCurrencySupported(\$isoCode)
    {
        foreach (\$this->getCurrencies() as \$currency) {
            if (\$currency->iso_code === \$isoCode) {
                return true;
            }
        }
        return false;
    }
}
