<?php
/**
 * Created by IntelliJ IDEA.
 * User: QZD2D0
 * Date: 1/6/2017
 * Time: 1:52 PM
 */
namespace App;

use GM\UAS\Core\Envelope\Contracts\Model\ModelObject;

/**
 * Class PaymentProcessorCurrency
 * @package App
 * @SWG\Definition(
 *     definition="PaymentProcessorCurrency",
 *     required={"processor","iso_code"}
 * )
 */
class PaymentProcessorCurrency extends ModelObject
{
    /**
     * @var string
     */
    protected \$table = 'payment_processor_currency';

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected \$fillable = [
        'id',
        'payment_processor_id',
        'iso_code',
        'created_at',
        'updated_at',
    ];

    /**
     * @var array
     */
    protected \$dates = ['created_at', 'updated_at'];

    /**
     * @return \App\PaymentProcessor
     */
    public function getProcessor()
    {
        /** @var PaymentProcessor \$processor */
        \$processor = \$this->hasOne(PaymentProcessor::class, 'id', 'payment_processor_id')->getQuery()->first();
        return \$processor;
    }

    /**
     * @SWG\Property(
     *     property="processor",
     *     type="object",
     *     @SWG\Property(
     *       property="id",
     *       type="string"
     *     )
     * )
     * @SWG\Property(property="iso_code", type="string")
     * @return array
     */
    public function asData()
    {
        return [
            'processor' => \$this->getProcessor()->asDataId(),
            'iso_code' => \$this->iso_code,
        ];
    }
}
