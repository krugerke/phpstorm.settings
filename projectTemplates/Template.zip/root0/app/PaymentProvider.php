<?php
/**
 * Created by IntelliJ IDEA.
 * User: QZD2D0
 * Date: 1/4/2017
 * Time: 2:00 PM
 */
namespace App;

use GM\UAS\Core\Envelope\Contracts\Model\ModelObject;

/**
 * Class PaymentProvider
 * @package App
 * @SWG\Definition(
 *     definition="PaymentProvider",
 *     required={"id","name","class","url"}
 * )
 */
class PaymentProvider extends ModelObject
{
    /**
     * @var string
     */
    protected \$table = 'payment_provider';

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected \$fillable = [
        'id',
        'guid',
        'name',
        'class',
        'url',
        'sandbox_url',
        'created_at',
        'updated_at',
    ];


    /**
     * @SWG\Property(
     *   property="id", type="string", minLength=34, maxLength=34,
     *   pattern="^[0-9a-fA-F]{8}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{12}\$"
     * )
     * @SWG\Property(property="name", type="string")
     * @SWG\Property(property="class", type="string")
     * @SWG\Property(property="url", type="string")
     * @SWG\Property(property="sandbox_url", type="string")
     * @SWG\Property(property="created_at", ref="\#/definitions/DateTime"))
     * @SWG\Property(property="updated_at", ref="\#/definitions/DateTime"))
     * @return array
     */
    public function asData()
    {
        return [
            'id' => \$this->guid,
            'name' => \$this->name,
            'class' => \$this->class,
            'url' => \$this->url,
            'sandbox_url' => \$this->sandbox_url,
            'created_at' => \$this->created_at,
            'updated_at' => \$this->updated_at,
        ];
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function getProcessors()
    {
        return \$this->hasMany(PaymentProcessor::class, 'payment_provider_id', 'id');
    }
}
