<?php
/**
 * Created by IntelliJ IDEA.
 * User: QZD2D0
 * Date: 1/9/2017
 * Time: 12:06 PM
 */
namespace App\PaymentProvider;

use App\Exceptions\PaymentFailedException;
use App\PaymentChannel;
use App\PaymentProcessor;
use App\PaymentProcessorCurrency;
use App\ProfileScript;
use App\Transaction;
use Illuminate\Http\Request;
use Omnipay\Omnipay;
use App\Exceptions\BadRequestException;
use App\PaymentProfile;
use Omnipay\PlanetPayment\Message\AbstractRequest;

/**
 * Class PlanetPayment
 * @package App\PaymentProvider
 */
class PlanetPayment implements PaymentProviderInterface
{
    /** @var PaymentProcessor */
    protected \$processor;

    /** @var PaymentProfile */
    protected \$profile;

    /** @var PaymentChannel */
    protected \$paymentChannel;

    /**
     * PlanetPayment constructor.
     * @param PaymentProcessor \$processor
     * @param PaymentChannel|null \$channel
     * @param PaymentProfile|null \$profile
     * @throws BadRequestException
     */
    public function __construct(
        PaymentProcessor \$processor,
        PaymentChannel \$channel = null,
        PaymentProfile \$profile = null
    ) {
        if (\$channel === null) {
            throw new BadRequestException('Payment channel is required for Planet Payment', -1);
        }
        \$this->processor = \$processor;
        \$this->profile = \$profile;
        \$this->paymentChannel = \$channel;
    }

    /**
     * @return \Omnipay\PlanetPayment\Gateway
     */
    protected function getGateway()
    {
        /** @var \Omnipay\PlanetPayment\Gateway \$gateway */
        \$gateway = Omnipay::create('PlanetPayment');
        \$gateway->initialize([
            'userId' => \$this->processor->getUsername(),
            'password' => \$this->processor->getPassword(),
            'entityId' => \$this->paymentChannel->channel,
            'testMode' => \$this->processor->sandbox,
            'useProxy' => env('USE_PROXY', false)
        ]);
        return \$gateway;
    }

    /**
     * @param Request \$request
     * @param \Omnipay\PlanetPayment\Message\PaymentResponse \$response
     * @return Transaction
     */
    private function createTransaction(Request \$request, \$response)
    {
        \$transaction = new Transaction([
            'guid' => createGUID(),
            'user_guid' => \$this->profile->user_guid,
            'payment_profile_id' => \$this->profile->id,
            'invoice' => \$request->get('invoice') ? \$request->get('invoice')['id'] : null,
            'reservation' => isset(\$request->get('reservation')['id']) ? \$request->get('reservation')['id'] : null,
            'amount' => \$request->get('amount'),
            'currency' => \$request->get('currency'),
            'descriptor' => \$request->get('descriptor'),
            'payment_channel_id' => \$this->paymentChannel->id,
            'gateway_id' => \$response->getTransactionReference(),
            'gateway_resp_code' => \$response->getCode(),
            'gateway_resp_message' => \$response->getMessage(),
        ]);
        if (\$response->isSuccessful()) {
            if (\$response->isApproved()) {
                \$transaction->status = Transaction::STATUS_APPROVED;
            } else {
                \$transaction->status = Transaction::STATUS_DECLINED;
            }
        } else {
            \$transaction->status = Transaction::STATUS_ERROR;
        }

        return \$transaction;
    }

    private function getFraudParams(Request \$request)
    {
        \$user = \$request->get('user');
        \$params = [
            AbstractRequest::PARAM_CUSTOMERIP => isset(\$user['customer_ip'])
                ? \$user['customer_ip'] : null,
            AbstractRequest::PARAM_FIRSTNAME => isset(\$user['first_name'])
                ? \$user['first_name'] : null,
            AbstractRequest::PARAM_LASTNAME => isset(\$user['last_name'])
                ? \$user['last_name'] : null,
            AbstractRequest::PARAM_INVOICEID => isset(\$request->get('invoice')['id'])
                ? \$request->get('invoice')['id'] : null,
            AbstractRequest::PARAM_MOBILE => isset(\$user['mobile'])
                ? \$user['mobile'] : null,
            AbstractRequest::PARAM_BIRTHDATE => isset(\$user['birth_date'])
                ? \$user['birth_date'] : null,
            AbstractRequest::PARAM_EMAIL => isset(\$user['email'])
                ? \$user['email'] : null,
            AbstractRequest::PARAM_TIMEONFILE => isset(\$user['time_on_file'])
                ? \$user['time_on_file'] : null,
            AbstractRequest::PARAM_DRIVERLICENSE => isset(\$user['driver_license'])
                ? \$user['driver_license'] : null,
            AbstractRequest::PARAM_STREET1 => isset(\$user['street1'])
                ? \$user['street1'] : null,
            AbstractRequest::PARAM_CITY => isset(\$user['city'])
                ? \$user['city'] : null,
            AbstractRequest::PARAM_STATE => isset(\$user['state'])
                ? \$user['state'] : null,
            AbstractRequest::PARAM_POSTCODE => isset(\$user['postcode'])
                ? \$user['post_code'] : null,
            AbstractRequest::PARAM_COUNTRY => isset(\$user['country'])
                ? \$user['country'] : null,
            AbstractRequest::PARAM_AVSRESPONSE => isset(\$user['avs_response'])
                ? \$user['avs_response'] : null,
            AbstractRequest::PARAM_DAYSENROLLED => isset(\$user['days_enrolled'])
                ? \$user['days_enrolled'] : null,
            AbstractRequest::PARAM_MERCHANTCUSTOMERID => isset(\$user['id'])
                ? \$user['id'] : null,
            AbstractRequest::PARAM_AGE => isset(\$user['age'])
                ? \$user['age'] : null,
        ];

        \$res = \$request->get('reservation');
        if (\$res) {
            \$params[AbstractRequest::PARAM_RESERVATIONID] = isset(\$res['id'])
                ? \$res['id'] : null;
            if (isset(\$res['pickup_datetime'], \$res['dropoff_datetime'])) {
                \$s = new \DateTime(\$res['pickup_datetime']);
                \$e = new \DateTime(\$res['dropoff_datetime']);
                \$diff = \$s->diff(\$e);
                \$params[AbstractRequest::PARAM_LENGTHOFRENTAL] = \$diff->format('%d days, %h hours');
            }

            \$params[AbstractRequest::PARAM_PROMOCODE] = isset(\$res['promo_code'])
                ? \$res['promo_code'] : null;

            \$params[AbstractRequest::PARAM_MAKEMODEL] = isset(\$res['vehicle']['make_model'])
                ? \$res['vehicle']['make_model'] : null;
            \$params[AbstractRequest::PARAM_RESERVATIONCREATE] = isset(\$res['creation_date'])
                ? \$res['creation_date'] : null;

            \$params[AbstractRequest::PARAM_PICKUPLOCATION] = isset(\$res['station_pickup']['location'])
                ? \$res['station_pickup']['location'] : null;
            \$params[AbstractRequest::PARAM_DROPOFFLOCATION] = isset(\$res['station_dropoff']['location'])
                ? \$res['station_dropoff']['location'] : null;
            \$params[AbstractRequest::PARAM_PICKUPADDRESS] = isset(\$res['station_pickup']['address'])
                ? \$res['station_pickup']['address'] : null;
            \$params[AbstractRequest::PARAM_PICKUPCITY] = isset(\$res['station_pickup']['city'])
                ? \$res['station_pickup']['city'] : null;
            \$params[AbstractRequest::PARAM_DROPOFFADDRESS] = isset(\$res['station_dropoff']['address'])
                ? \$res['station_dropoff']['address'] : null;
            \$params[AbstractRequest::PARAM_DROPOFFCITY] = isset(\$res['station_dropoff']['city'])
                ? \$res['station_dropoff']['city'] : null;
        }
        return \$params;
    }
    /**
     * @param Request \$request
     * @return Transaction
     * @throws \Exception
     * @throws BadRequestException
     * @throws PaymentFailedException
     */
    public function auth(Request \$request)
    {
        if (empty(\$request->get('amount'))) {
            throw new BadRequestException('Amount is required to auth', -1);
        }
        if (empty(\$request->get('currency'))) {
            throw new BadRequestException('Currency is required to auth', -1);
        }

        // Prepare request param to payment gateway
        \$params = [

            AbstractRequest::PARAM_AMOUNT => (float)sprintf('%.02f', \$request->get('amount') / 100),
            AbstractRequest::PARAM_CURRENCYCODE => \$request->get('currency'),
            AbstractRequest::PARAM_DESCRIPTOR => \$request->get('descriptor') ?: '',
            AbstractRequest::PARAM_REGISTRATIONID => \$this->profile->token,
            AbstractRequest::PARAM_BIN => \$this->profile->bin,
        ];
        if (\$request->get('installments') > 1) {
            \$params[AbstractRequest::PARAM_INSTALLMENTS] = \$request->get('installments');
        }

        if (\$request->get('invoiceId') > 1) {
            \$params[AbstractRequest::PARAM_INVOICEID] = \$request->get('invoiceId');
        }

        \$fraudParams = \$this->getFraudParams(\$request);
        \$params = array_merge(\$fraudParams, \$params);

        try {
            \$gateway = \$this->getGateway();

            /** @var \Omnipay\PlanetPayment\Message\PaymentResponse \$response */
            \$response = \$gateway->authorize(\$params)->send();
        } catch (\Exception \$e) {
            throw new PaymentFailedException(\$e->getMessage(), \$e->getCode(), \$e);
        }

        \$transaction = \$this->createTransaction(\$request, \$response);
        \$transaction->type = Transaction::TYPE_AUTH;

        \$transaction->save();

        return \$transaction;
    }

    /**
     * @param Request \$request
     * @return Transaction
     * @throws \Exception
     * @throws BadRequestException
     * @throws PaymentFailedException
     */
    public function cap(Request \$request)
    {
        if (empty(\$request->get('related_transaction'))) {
            throw new BadRequestException('related_transaction is required to capture', -1);
        }
        /** @var Transaction \$auth */
        \$auth = Transaction::query()->where('gateway_id', '=', \$request->get('related_transaction')['id'])->first();
        if (\$auth === null) {
            throw new BadRequestException('related_transaction not found', -1);
        }
        \$amount = \$request->get('amount', \$auth->amount);
        if (\$amount <= 0) {
            throw new BadRequestException('Zero or negative amount is not allowed on capture', -1);
        }
        \$currency = \$request->get('currency', \$auth->currency);

        \$params = [
            AbstractRequest::PARAM_ID => \$auth->gateway_id,
            AbstractRequest::PARAM_AMOUNT => (float)sprintf('%.02f', \$amount / 100),
            AbstractRequest::PARAM_CURRENCYCODE => \$currency,
            AbstractRequest::PARAM_BIN => \$this->profile->bin,
        ];

        if (\$request->get('invoiceId') > 1) {
            \$params[AbstractRequest::PARAM_INVOICEID] = \$request->get('invoiceId');
        }

        try {
            \$gateway = \$this->getGateway();

            /** @var \Omnipay\PlanetPayment\Message\PaymentResponse \$response */
            \$response = \$gateway->capture(\$params)->send();
        } catch (\Exception \$e) {
            throw new PaymentFailedException(\$e->getMessage(), \$e->getCode(), \$e);
        }

        \$transaction = \$this->createTransaction(\$request, \$response);
        \$transaction->type = Transaction::TYPE_CAP;

        \$transaction->save();

        return \$transaction;
    }

    /**
     * @param Request \$request
     * @return Transaction
     * @throws \Exception
     * @throws BadRequestException
     * @throws PaymentFailedException
     */
    public function authcap(Request \$request)
    {
        if (empty(\$request->get('amount'))) {
            throw new BadRequestException('Amount is required to auth', -1);
        }
        if (empty(\$request->get('currency'))) {
            throw new BadRequestException('Currency is required to auth', -1);
        }

        // Prepare request param to payment gateway
        \$params = [
            AbstractRequest::PARAM_AMOUNT => (float)sprintf('%.02f', \$request->get('amount') / 100),
            AbstractRequest::PARAM_CURRENCYCODE => \$request->get('currency'),
            AbstractRequest::PARAM_DESCRIPTOR => \$request->get('descriptor') ?: '',
            AbstractRequest::PARAM_REGISTRATIONID => \$this->profile->token,
            AbstractRequest::PARAM_BIN => \$this->profile->bin,
        ];
        if (\$request->get('installments') > 1) {
            \$params[AbstractRequest::PARAM_INSTALLMENTS] = \$request->get('installments');
        }

        if (\$request->get('invoiceId') > 1) {
            \$params[AbstractRequest::PARAM_INVOICEID] = \$request->get('invoiceId');
        }

        \$fraudParams = \$this->getFraudParams(\$request);
        \$params = array_merge(\$fraudParams, \$params);

        try {
            \$gateway = \$this->getGateway();

            /** @var \Omnipay\PlanetPayment\Message\PaymentResponse \$response */
            \$response = \$gateway->purchase(\$params)->send();
        } catch (\Exception \$e) {
            throw new PaymentFailedException(\$e->getMessage(), \$e->getCode(), \$e);
        }

        \$transaction = \$this->createTransaction(\$request, \$response);
        \$transaction->type = Transaction::TYPE_AUTHCAP;

        \$transaction->save();

        return \$transaction;
    }

    /**
     * @param Request \$request
     * @return Transaction
     * @throws \Exception
     * @throws BadRequestException
     * @throws PaymentFailedException
     */
    public function void(Request \$request)
    {
        if (empty(\$request->get('related_transaction'))) {
            throw new BadRequestException('related_transaction is required to capture', -1);
        }
        /** @var Transaction \$auth */
        \$originalTrans = Transaction::query()
            ->where('gateway_id', '=', \$request->get('related_transaction')['id'])->first();
        if (empty(\$originalTrans)) {
            throw new BadRequestException('related_transaction not found', -1);
        }


        \$params = [
            AbstractRequest::PARAM_ID => \$originalTrans->gateway_id,
            AbstractRequest::PARAM_BIN => \$this->profile->bin,
        ];

        try {
            \$gateway = \$this->getGateway();

            /** @var \Omnipay\PlanetPayment\Message\PaymentResponse \$response */
            \$response = \$gateway->void(\$params)->send();
        } catch (\Exception \$e) {
            throw new PaymentFailedException(\$e->getMessage(), \$e->getCode(), \$e);
        }

        \$transaction = \$this->createTransaction(\$request, \$response);
        \$transaction->type = Transaction::TYPE_VOID;

        \$transaction->save();

        return \$transaction;
    }

    /**
     * @param Request \$request
     * @return Transaction
     * @throws \Exception
     * @throws BadRequestException
     * @throws PaymentFailedException
     */
    public function refund(Request \$request)
    {
        if (empty(\$request->get('related_transaction'))) {
            throw new BadRequestException('related_transaction is required to refund', -1);
        }
        /** @var Transaction \$auth */
        \$auth = Transaction::query()->where('gateway_id', '=', \$request->get('related_transaction')['id'])->first();
        if (\$auth === null) {
            throw new BadRequestException('related_transaction not found', -1);
        }
        \$amount = \$request->get('amount', \$auth->amount);
        if (\$amount <= 0) {
            throw new BadRequestException('Zero or negative amount is not allowed on capture', -1);
        }
        \$currency = \$request->get('currency', \$auth->currency);

        \$params = [
            AbstractRequest::PARAM_ID => \$auth->gateway_id,
            AbstractRequest::PARAM_AMOUNT => (float)sprintf('%.02f', \$amount / 100),
            AbstractRequest::PARAM_CURRENCYCODE => \$currency,
            AbstractRequest::PARAM_BIN => \$this->profile->bin,
        ];

        try {
            \$gateway = \$this->getGateway();

            /** @var \Omnipay\PlanetPayment\Message\PaymentResponse \$response */
            \$response = \$gateway->refund(\$params)->send();
        } catch (\Exception \$e) {
            throw new PaymentFailedException(\$e->getMessage(), \$e->getCode(), \$e);
        }

        \$transaction = \$this->createTransaction(\$request, \$response);
        \$transaction->type = Transaction::TYPE_REFUND;

        \$transaction->save();

        return \$transaction;
    }

    /**
     * @param Request \$request
     * @return Transaction
     * @throws \Exception
     * @throws BadRequestException
     * @throws PaymentFailedException
     */
    public function credit(Request \$request)
    {
        if (empty(\$request->get('amount'))) {
            throw new BadRequestException('Amount is required to auth', -1);
        }
        if (empty(\$request->get('currency'))) {
            throw new BadRequestException('Currency is required to auth', -1);
        }

        // Prepare request param to payment gateway
        \$params = [
            AbstractRequest::PARAM_AMOUNT => (float)sprintf('%.02f', \$request->get('amount') / 100),
            AbstractRequest::PARAM_CURRENCYCODE => \$request->get('currency'),
            AbstractRequest::PARAM_DESCRIPTOR => \$request->get('descriptor') ?: '',
            AbstractRequest::PARAM_REGISTRATIONID => \$this->profile->token,
            AbstractRequest::PARAM_BIN => \$this->profile->bin,
        ];
        if (\$request->get('installments') > 1) {
            \$params[AbstractRequest::PARAM_INSTALLMENTS] = \$request->get('installments');
        }

        if (\$request->get('invoiceId') > 1) {
            \$params[AbstractRequest::PARAM_INVOICEID] = \$request->get('invoiceId');
        }

        \$fraudParams = \$this->getFraudParams(\$request);
        \$params = array_merge(\$fraudParams, \$params);

        try {
            \$gateway = \$this->getGateway();

            /** @var \Omnipay\PlanetPayment\Message\PaymentResponse \$response */
            \$response = \$gateway->credit(\$params)->send();
        } catch (\Exception \$e) {
            throw new PaymentFailedException(\$e->getMessage(), \$e->getCode(), \$e);
        }

        \$transaction = \$this->createTransaction(\$request, \$response);
        \$transaction->type = Transaction::TYPE_CREDIT;

        \$transaction->save();

        return \$transaction;
    }

    /**
     * @param Request \$request
     * @return ProfileScript
     * @throws PaymentFailedException
     */
    public function profileScript(Request \$request)
    {
        /** @var PaymentProcessorCurrency \$currency */
        \$currency = PaymentProcessorCurrency::query()
            ->where('payment_processor_id', '=', \$this->processor->id)->first();

        \$params = array(
            AbstractRequest::PARAM_MERCHANTCUSTOMERID => \$request->get('user')['id'],
            AbstractRequest::PARAM_CURRENCYCODE => \$currency->iso_code,
        );

        \$fraudParams = \$this->getFraudParams(\$request);
        \$params = array_merge(\$fraudParams, \$params);

        /** @var \Omnipay\PlanetPayment\Gateway \$gateway */
        \$gateway = \$this->getGateway();

        /** @var \Omnipay\PlanetPayment\Message\CheckoutResponse \$response */
        \$response = \$gateway->checkout(\$params)->send();

        if (!\$response->isSuccessful()) {
            throw new PaymentFailedException(\$response->getMessage(), \$response->getCode());
        }

        \$profile = new ProfileScript([
            'guid' => createGUID(),
            'user_guid' => \$request->get('user')['id'],
            'payment_processor_id' => \$this->processor->id,
            'payment_channel_id' => \$this->paymentChannel->id,
            'script_url' => \$response->getPipeScriptUrl(),
            'gateway_id' => \$response->getCheckoutId(),
        ]);
        \$profile->save();

        return \$profile;
    }

    /**
     * @param Request \$request
     * @param \$id
     * @return ProfileScript
     * @throws BadRequestException
     */
    public function profileScriptStatus(Request \$request, \$id)
    {
        /** @var ProfileScript \$script */
        \$script = ProfileScript::query()->where('gateway_id', '=', \$id)->first();
        if (\$script === null) {
            throw new BadRequestException('ProfileScript not found', -1);
        }

        /**
         * TODO resourcePath should probably come from the JS response, in case PP changes their API version
         */
        \$params = [
            AbstractRequest::PARAM_RESOURCEPATH => '/v1/checkouts/'.\$script->gateway_id.'/payment',
            AbstractRequest::PARAM_BIN => \$request->get('bin'),
        ];

        /** @var \Omnipay\PlanetPayment\Gateway \$gateway */
        \$gateway = \$this->getGateway();

        /** @var \Omnipay\PlanetPayment\Message\CheckoutStatusResponse \$response */
        \$response = \$gateway->checkoutStatus(\$params)->send();

        \$script->update([
            'response_code' => \$response->getCode(),
            'response_message' => \$response->getMessage(),
        ]);
        if (\$response->isSuccessful()) {
            if (\$response->isApproved()) {
                \$script->status = ProfileScript::STATUS_APPROVED;

                \$profile = new PaymentProfile([
                    'guid' => createGUID(),
                    'payment_provider_id' => \$this->processor->getProvider()->id,
                    'user_guid' => \$script->user_guid,
                    'token' => \$response->getRegistrationId(),
                    'bin' => \$response->getCardBin(),
                    'last4' => \$response->getLastFour(),
                    'exp_month' => str_pad(\$response->getExpMonth(), 2, '0', STR_PAD_LEFT),
                    'exp_year' => \$response->getExpYear(),
                    'card_brand' => \$response->getPaymentBrand(),
                    'avs_response' => \$response->getAVSCode(),
                    'default' => \$request->get('default') ? 1 : 0,
                ]);
                \$profile->save();
                \$script->payment_profile_id = \$profile->id;
            } else {
                \$script->status = ProfileScript::STATUS_DECLINED;
            }
        } else {
            \$script->status = ProfileScript::STATUS_ERROR;
        }
        \$script->save();

        return \$script;
    }
}
