<?php
/**
 * Created by IntelliJ IDEA.
 * User: QZD2D0
 * Date: 1/9/2017
 * Time: 3:16 PM
 */

namespace App;

use GM\UAS\Core\Envelope\Contracts\Model\ModelObject;

/**
 * Class ProfileScript
 * @package App
 * @SWG\Definition(
 *     definition="ProfileScript",
 *     required={"id","user","processor","payment_channel"}
 * )
 */
class ProfileScript extends ModelObject
{
    /**
     *
     */
    const STATUS_DECLINED = 0;
    /**
     *
     */
    const STATUS_APPROVED = 1;
    /**
     *
     */
    const STATUS_ERROR = 2;

    /**
     * @var string
     */
    protected \$table = 'payment_profile_script';

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected \$fillable = [
        'id',
        'guid',
        'user_guid',
        'payment_processor_id',
        'payment_channel_id',
        'script_url',
        'gateway_id',
        'status',
        'response_code',
        'response_message',
        'avs_response',
        'created_at',
        'updated_at',
    ];

    /**
     * @SWG\Property(
     *   property="id", type="string", minLength=34, maxLength=34,
     *   pattern="^[0-9a-fA-F]{8}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{12}\$"
     * )
     * @SWG\Property(property="user", ref="\#/definitions/ObjectId")
     * @SWG\Property(property="processor", ref="\#/definitions/ObjectId")
     * @SWG\Property(property="payment_channel", ref="\#/definitions/ObjectId")
     * @SWG\Property(property="script_url", type="string")
     * @SWG\Property(property="gateway_id", type="string")
     * @SWG\Property(property="status", type="integer")
     * @SWG\Property(property="response_code", type="string")
     * @SWG\Property(property="response_message", type="string")
     * @SWG\Property(property="avs_response", type="string")
     * @SWG\Property(property="profile", ref="\#/definitions/ObjectId")
     * @SWG\Property(property="created_at", ref="\#/definitions/DateTime"))
     * @SWG\Property(property="updated_at", ref="\#/definitions/DateTime"))
     * @return array
     */
    public function asData()
    {
        return [
            'id' => \$this->gateway_id,
            'user' => ['id' => \$this->user_guid],
            'processor' => \$this->getProcessor()->asDataId(),
            'payment_channel' => \$this->getChannel()->asDataId(),
            'script_url' => \$this->script_url,
            'gateway_id' => \$this->gateway_id,
            'status' => \$this->status,
            'response_code' => \$this->response_code,
            'response_message' => \$this->response_message,
            'avs_response' => \$this->avs_response,
            'profile' => \$this->getProfile() ? \$this->getProfile()->asData() : null,
            'created_at' => \$this->created_at,
            'updated_at' => \$this->updated_at,
        ];
    }

    public function asDataId()
    {
        return [
            'id' => \$this->gateway_id,
        ];
    }

    /**
     * @return \App\PaymentProcessor
     */
    public function getProcessor()
    {
        /** @var PaymentProcessor \$processor */
        \$processor = \$this->hasOne(PaymentProcessor::class, 'id', 'payment_processor_id')->getQuery()->first();
        return \$processor;
    }

    /**
     * @return \App\PaymentChannel
     */
    public function getChannel()
    {
        /** @var PaymentChannel \$channel */
        \$channel = \$this->hasOne(PaymentChannel::class, 'id', 'payment_channel_id')->getQuery()->first();
        return \$channel;
    }
    /**
     * @return \App\PaymentProfile
     */
    public function getProfile()
    {
        /** @var \App\PaymentProfile \$profile */
        \$profile = \$this->hasOne(PaymentProfile::class, 'id', 'payment_profile_id')->getQuery()->first();
        return \$profile;
    }
}
