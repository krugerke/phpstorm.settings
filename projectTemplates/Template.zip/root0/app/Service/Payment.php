<?php
/**
 * Created by IntelliJ IDEA.
 * User: QZD2D0
 * Date: 1/9/2017
 * Time: 12:06 PM
 */
namespace App\Service;

use App\PaymentChannel;
use App\PaymentProcessor;
use App\PaymentProvider\PaymentProviderInterface;
use App\Transaction;
use Illuminate\Http\Request;
use App\PaymentProfile;
use App\Exceptions\BadRequestException;
use App\Exceptions\PaymentFailedException;

/**
 * Class Payment
 * @package App\Service
 */
class Payment
{
    /** @var  PaymentProviderInterface */
    protected \$provider;

    /** @var PaymentProfile */
    protected \$profile;

    /**
     * Payment constructor.
     * @param Request \$request
     * @throws BadRequestException
     */
    public function __construct(Request \$request)
    {
        /*
         * TODO look up profile by user and supported currency
         */
        /** @var \App\PaymentProfile \$profile */
        if (!empty(\$request->get('profile'))) {
            \$profile = PaymentProfile::query()->where('token', '=', \$request->get('profile')['id'])->first();
        } else {
            \$profile = PaymentProfile::query()->where('user_guid', '=', \$request->get('user')['id'])
                ->where('default', '=', true)->first();
        }
        \$this->profile = \$profile;

        /** @var PaymentProcessor \$processor */
        /** @var PaymentChannel \$channel */
        \$channel = null;
        if (!empty(\$request->get('payment_channel'))) {
            \$channel = PaymentChannel::query()->where('channel', '=', \$request->get('payment_channel')['id'])->first();
            if (empty(\$channel)) {
                throw new BadRequestException('Unable to find payment channel', -1);
            }
            \$processor = \$channel->getProcessor();
        } else {
            if (empty(\$request->get('processor'))) {
                throw new BadRequestException('Processor is required', -1);
            }
            \$processor = PaymentProcessor::query()->where('guid', '=', \$request->get('processor')['id'])->first();
        }
        if (empty(\$processor)) {
            throw new BadRequestException('Unable to find payment processor', -1);
        }


        \$class = '\App\PaymentProvider\\'.\$processor->getProvider()->class;
        \$this->provider = new \$class(\$processor, \$channel, \$this->profile);
    }

    /**
     * @param Request \$request
     * @return Transaction
     * @throws \Exception
     * @throws BadRequestException
     * @throws PaymentFailedException
     */
    public function processTransaction(Request \$request)
    {
        if (empty(\$this->profile)) {
            throw new BadRequestException('Unable to find payment profile', -1);
        }

        \$type = \$request->get('type');
        /** @var Transaction \$transaction */
        \$transaction = \$this->provider->\$type(\$request);

        return \$transaction;
    }
}
