<?php
/**
 * Created by IntelliJ IDEA.
 * User: QZD2D0
 * Date: 1/9/2017
 * Time: 4:29 PM
 */

namespace App\Service;

use App\PaymentChannel;
use App\PaymentProcessor;
use App\PaymentProvider\PaymentProviderInterface;
use App\ProfileScript;
use Illuminate\Http\Request;
use App\Exceptions\BadRequestException;

/**
 * Class PaymentProfile
 * @package App\Service
 */
class PaymentProfile
{
    /** @var  PaymentProviderInterface */
    protected \$provider;

    /** @var ProfileScript  */
    protected \$profile;

    /**
     * Payment constructor.
     * @param Request \$request
     * @param ProfileScript \$script
     * @throws BadRequestException
     */
    public function __construct(Request \$request, ProfileScript \$script = null)
    {
        /** @var PaymentProcessor \$processor */
        if (!empty(\$script)) {
            \$this->profile = \$script;
            \$processor = \$this->profile->getProcessor();
            \$paymentChannel = \$script->getChannel();
        } else {
            /** @var PaymentChannel \$paymentChannel */
            \$paymentChannel = PaymentChannel::query()
                ->where('channel', '=', \$request->get('payment_channel')['id'])->first();
            \$processor = \$paymentChannel->getProcessor();
        }
        if (empty(\$processor)) {
            throw new BadRequestException('Unable to find payment processor', -1);
        }

        \$class = '\App\PaymentProvider\\' . \$processor->getProvider()->class;
        \$this->provider = new \$class(\$processor, \$paymentChannel);
    }

    /**
     * @param Request \$request
     * @return ProfileScript
     */
    public function getProfileScript(Request \$request)
    {
        \$profileScript = \$this->provider->profileScript(\$request);

        return \$profileScript;
    }

    /**
     * @param Request \$request
     * @param \$id
     * @return ProfileScript
     */
    public function getProfileScriptStatus(Request \$request, \$id)
    {
        return \$this->provider->profileScriptStatus(\$request, \$id);
    }
}
