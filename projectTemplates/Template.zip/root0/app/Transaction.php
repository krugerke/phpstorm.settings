<?php
/**
 * Created by IntelliJ IDEA.
 * User: QZD2D0
 * Date: 1/9/2017
 * Time: 9:23 AM
 */

namespace App;

use GM\UAS\Core\Envelope\Contracts\Model\ModelObject;

/**
 * Class Transaction
 * @package App
 * @SWG\Definition(
 *     definition="Transaction",
 *     required={"id","user","type","profile"}
 * )
 */
class Transaction extends ModelObject
{
    /**
     * @var string
     */
    protected \$table = 'payment_transaction';

    /**
     *
     */
    const STATUS_DECLINED = 0;
    /**
     *
     */
    const STATUS_APPROVED = 1;
    /**
     *
     */
    const STATUS_ERROR = 2;

    /**
     *
     */
    const TYPE_AUTH = 'auth';
    /**
     *
     */
    const TYPE_CAP = 'cap';
    /**
     *
     */
    const TYPE_AUTHCAP = 'authcap';
    /**
     *
     */
    const TYPE_VOID = 'void';
    /**
     *
     */
    const TYPE_REFUND = 'refund';
    /**
     *
     */
    const TYPE_CREDIT = 'credit';

    /**
     * @return array
     */
    public static function listTypes()
    {
        return [
            self::TYPE_AUTH,
            self::TYPE_CAP,
            self::TYPE_AUTHCAP,
            self::TYPE_VOID,
            self::TYPE_REFUND,
            self::TYPE_CREDIT,
        ];
    }

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected \$fillable = [
        'id',
        'guid',
        'user_guid',
        'payment_profile_id',
        'invoice',
        'reservation',
        'type',
        'amount',
        'currency',
        'descriptor',
        'status',
        'gateway_id',
        'gateway_resp_code',
        'gateway_resp_message',
        'payment_channel_id',
        'related_transaction_id',
        'avs_response',
        'created_at',
        'updated_at',
    ];

    /**
     * @SWG\Property(
     *   property="id", type="string", minLength=34, maxLength=34,
     *   pattern="^[0-9a-fA-F]{8}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{12}\$"
     * )
     * @SWG\Property(property="user", ref="\#/definitions/ObjectId")
     * @SWG\Property(property="profile", ref="\#/definitions/ObjectId")
     * @SWG\Property(property="invoice", ref="\#/definitions/ObjectIdAny")
     * @SWG\Property(property="reservation", ref="\#/definitions/ObjectIdAny")
     * @SWG\Property(property="type", type="string")
     * @SWG\Property(property="amount", type="integer")
     * @SWG\Property(property="currency", type="string")
     * @SWG\Property(property="descriptor", type="string")
     * @SWG\Property(property="status", type="integer")
     * @SWG\Property(property="gateway_id", type="string")
     * @SWG\Property(property="gateway_resp_code", type="string")
     * @SWG\Property(property="gateway_resp_message", type="string")
     * @SWG\Property(property="avs_response", type="string")
     * @SWG\Property(property="payment_channel", ref="\#/definitions/ObjectId")
     * @SWG\Property(property="related_transaction", ref="\#/definitions/ObjectId")
     * @SWG\Property(property="created_at", ref="\#/definitions/DateTime"))
     * @SWG\Property(property="updated_at", ref="\#/definitions/DateTime"))
     * @return array
     */
    public function asData()
    {
        return [
            'id' => \$this->gateway_id,
            'profile' => \$this->getProfile()->asDataId(),
            'user' => ['id' => \$this->user_guid],
            'invoice' => ['id' => \$this->invoice],
            'reservation' => ['id' => \$this->reservation],
            'type' => \$this->type,
            'amount' => \$this->amount,
            'currency' => \$this->currency,
            'descriptor' => \$this->descriptor,
            'status' => \$this->status,
            'gateway_id' => \$this->gateway_id,
            'gateway_resp_code' => \$this->gateway_resp_code,
            'gateway_resp_message' => \$this->gateway_resp_message,
            'avs_response' => \$this->avs_response,
            'payment_channel' => \$this->getPaymentChannel() ? \$this->getPaymentChannel()->asDataId() : null,
            'related_transaction' => \$this->getRelatedTransaction()
                ? \$this->getRelatedTransaction()->asDataId() : null,
            'created_at' => \$this->created_at,
            'updated_at' => \$this->updated_at,
        ];
    }

    public function asDataId()
    {
        return [
            'id' => \$this->gateway_id,
        ];
    }

    /**
     * @return \App\PaymentProfile
     */
    public function getProfile()
    {
        /** @var PaymentProfile \$profile */
        \$profile = \$this->hasOne(PaymentProfile::class, 'id', 'payment_profile_id')->getQuery()->first();
        return \$profile;
    }

    /**
     * @return Transaction
     */
    public function getRelatedTransaction()
    {
        /** @var Transaction \$transaction */
        \$transaction = \$this->hasOne(Transaction::class, 'id', 'related_transaction_id')->getQuery()->first();
        return \$transaction;
    }

    /**
     * @return PaymentChannel
     */
    public function getPaymentChannel()
    {
        /** @var PaymentChannel \$channel */
        \$channel = \$this->hasOne(PaymentChannel::class, 'id', 'payment_channel_id')->getQuery()->first();
        return \$channel;
    }
}
