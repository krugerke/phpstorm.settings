<?php

return [
    'oracle' => [
        'driver'       => 'oracle',
        'host'         => isset(\$_ENV['CREDENTIALS']['ORACLE_BILLINGANDPAYMENT']['DB_HOST'])
            ? \$_ENV['CREDENTIALS']['ORACLE_BILLINGANDPAYMENT']['DB_HOST'] : env('DB_HOST', '127.0.0.1'),
        'port'         => isset(\$_ENV['CREDENTIALS']['ORACLE_BILLINGANDPAYMENT']['DB_PORT'])
            ? \$_ENV['CREDENTIALS']['ORACLE_BILLINGANDPAYMENT']['DB_PORT'] : env('DB_PORT', 1521),
        'database'     => isset(\$_ENV['CREDENTIALS']['ORACLE_BILLINGANDPAYMENT']['DB_DATABASE'])
            ? \$_ENV['CREDENTIALS']['ORACLE_BILLINGANDPAYMENT']['DB_DATABASE'] : env('DB_DATABASE', ''),
        'username'     => isset(\$_ENV['CREDENTIALS']['ORACLE_BILLINGANDPAYMENT']['DB_USERNAME'])
            ? \$_ENV['CREDENTIALS']['ORACLE_BILLINGANDPAYMENT']['DB_USERNAME'] : env('DB_USERNAME', ''),
        'password'     => isset(\$_ENV['CREDENTIALS']['ORACLE_BILLINGANDPAYMENT']['DB_PASSWORD'])
            ? \$_ENV['CREDENTIALS']['ORACLE_BILLINGANDPAYMENT']['DB_PASSWORD'] : env('DB_PASSWORD', ''),
        'service_name' => isset(\$_ENV['CREDENTIALS']['ORACLE_BILLINGANDPAYMENT']['DB_SERVICE_NAME'])
            ? \$_ENV['CREDENTIALS']['ORACLE_BILLINGANDPAYMENT']['DB_SERVICE_NAME'] : env('DB_SERVICE_NAME', ''),
        'charset'      => env('DB_CHARSET', 'AL32UTF8'),
        'prefix'       => env('DB_PREFIX', ''),
    ],
];
