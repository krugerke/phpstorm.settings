<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreatePaymentProviderTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('payment_provider', function (Blueprint \$table) {
            \$table->increments('id');
            \$table->string('guid', 36);
            \$table->string('name', 64);
            \$table->string('class', 64);
            \$table->string('url');
            \$table->string('sandbox_url');
            \$table->unique(['guid']);
            \$table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::drop('payment_provider');
    }
}
