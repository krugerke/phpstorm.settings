<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreatePaymentProfileTable extends Migration
{
    /**
     * 	user
    processor
    token
    bin
    last4
    exp_month
    exp_year
    brand
    default
     */
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('payment_profile', function (Blueprint \$table) {
            \$table->increments('id');
            \$table->string('guid', 36);
            \$table->string('user_guid', 36);
            \$table->integer('payment_provider_id', false, true);
            \$table->string('token')->unique();
            \$table->string('bin')->nullable();
            \$table->string('last4');
            \$table->char('exp_month', 2)->nullable();
            \$table->char('exp_year', 4)->nullable();
            \$table->string('card_brand', 16)->nullable();
            \$table->string('avs_response', 16)->nullable();
            \$table->boolean('default');
            \$table->timestamps();
            \$table->unique(['guid']);
            \$table->foreign('payment_provider_id')->references('id')->on('payment_provider');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::drop('payment_profile', function (Blueprint \$table) {
            //
        });
    }
}
