<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateProfileScriptTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('payment_profile_script', function (Blueprint \$table) {
            \$table->increments('id');
            \$table->string('guid', 36);
            \$table->string('user_guid', 36);
            \$table->integer('payment_processor_id')->unsigned();
            \$table->integer('payment_channel_id')->unsigned();
            \$table->string('script_url');
            \$table->string('gateway_id');
            \$table->integer('status')->unsigned()->nullable();
            \$table->string('response_code', 16)->nullable();
            \$table->string('response_message')->nullable();
            \$table->string('avs_response', 16)->nullable();
            \$table->integer('payment_profile_id')->unsigned()->nullable();
            \$table->foreign('payment_processor_id', 'fk_profile_script_processor')->references('id')->on('payment_processor');
            \$table->foreign('payment_profile_id', 'fk_profile_script_profile')->references('id')->on('payment_profile');
            \$table->unique('guid');
            \$table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::drop('payment_profile_script');
    }
}
