<?php
/**
 * Created by IntelliJ IDEA.
 * User: qzd2d0
 * Date: 1/24/2017
 * Time: 4:58 PM
 */

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateErrorLogTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::connection('error_log')->create('error_log', function (Blueprint \$table) {
            \$table->increments('id');
            \$table->string('service');
            \$table->string('route');
            \$table->string('logger', 32);
            \$table->string('errfile')->nullable();
            \$table->integer('errline')->nullable();
            \$table->string('typestr')->nullable();
            \$table->text('errstr')->nullabe();
            \$table->integer('errno')->nullable();
            \$table->text('trace')->nullable();
            \$table->text('request')->nullable();
            \$table->string('vcap_request_id')->nullable();
            \$table->timestamps();
            \$table->index(['route']);
            \$table->index(['service']);
            \$table->index(['vcap_request_id']);
            \$table->index(['created_at']);
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::connection('error_log')->drop('error_log');
    }
}
