<?php
/**
 * Created by IntelliJ IDEA.
 * User: QZD2D0
 * Date: 1/5/2017
 * Time: 9:43 AM
 */
use Illuminate\Database\Seeder;

class PaymentProviderTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        App\PaymentProvider::create([
            'guid' => createGUID(),
            'name' => 'Planet Payment',
            'class' => 'PlanetPayment',
            'url' => 'https://planetpaymentgateway.com',
            'sandbox_url' => 'https://test.planetpaymentgateway.com',
        ]);
    }
}
