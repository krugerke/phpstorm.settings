\# GM UAS Payment Service

Endpoints:
----

\#\# GET /payment/provider


\#\# GET /payment/provider/{id}


\#\# GET /payment/processor


\#\# GET /payment/processor/{id}


\#\# POST /payment/processor


\#\# PUT /payment/processor/{id}


\#\# POST /payment/processor/{id}/currency


\#\# DELETE /payment/processor/{id}/currency


\#\# GET /payment/processor/{pid}/channel


\#\# GET /payment/processor/{pid}/channel/{id}


\#\# POST /payment/processor/{pid}/channel


\#\# PUT /payment/processor/{pic}/channel/{id}


\#\# GET /payment/profile


\#\# GET /payment/profile/{id}


\#\# POST /payment/profile

Not used by Planet Payment flow, but might be used by future providers. Will be useful for migrating profiles from Maven.

\#\# PUT /payment/profile/{id}


\#\# GET /payment/transaction

Available filters:
* invoice[id]
* reservation[id]
* user[id]

\#\# GET /payment/transaction/{id}


\#\# POST /payment/transaction

Available transaction types:
* auth
* cap
* authcap
* void
* refund
* credit

Transaction statuses:
* 0 - DECLINED
* 1 - APPROVED
* 2 - ERROR (rare)

Amount is in cents. For example, \$1.00 would be passed as 100.

| type                           | auth | cap | authcap | void | refund | credit |
|--------------------------------|------|-----|---------|------|--------|--------|
| user                           | D    | D   | D       | D    | D      | D      |
| profile                        | D    | D   | D       | D    | D      | D      |
| amount                         | R    | O   | R       |      | O      | R      |
| currency                       | R    | O   | R       |      | O      | R      |
| descriptor                     | O    |     | O       |      | O      | O      |
| payment_channel                | D    | D   | D       | D    | D      | D      |
| first_name                     |      |     |         |      |        |        |
| last_name                      |      |     |         |      |        |        |
| mobile                         |      |     |         |      |        |        |
| email                          |      |     |         |      |        |        |
| birth_date                     |      |     |         |      |        |        |
| time_on_file                   |      |     |         |      |        |        |
| driver_license                 |      |     |         |      |        |        |
| invoice[id]                    |      |     |         |      |        |        |
| reservation[id]                |      |     |         |      |        |        |
| reservation[pick_up_datetime]  |      |     |         |      |        |        |
| reservation[drop_off_datetime] |      |     |         |      |        |        |
| reservation[pick_up_location]  |      |     |         |      |        |        |
| reservation[drop_off_location] |      |     |         |      |        |        |

\#\# POST /payment/profilescript


\#\# GET /payment/profilescript/{id}/status
