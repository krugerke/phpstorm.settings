<?php
/**
 * Created by IntelliJ IDEA.
 * User: QZD2D0
 * Date: 1/10/2017
 * Time: 10:06 AM
 */
namespace Tests\Http\Controllers;

use TestCase;

class PaymentProviderControllerTest extends TestCase
{
    public function testIndex()
    {
        \$get = \$this->get('/api/v1/payment/provider')
            ->seeJson([
                'status' => 'success'
            ]);
    }

    public function testShow()
    {
        \$get = \$this->get('/api/v1/payment/provider');
        \$json = json_decode(\$get->response->getContent(), true);

        \$this->assertNotEmpty(\$json);
        \$this->assertNotEmpty(\$json['data']);
        \$get = \$this->get('/api/v1/payment/provider/'.\$json['data'][0]['id'])
            ->seeJson(['status' => 'success']);
    }
}
