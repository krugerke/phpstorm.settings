<?php

namespace App\Console;

use Illuminate\Console\Scheduling\Schedule;
use Laravel\Lumen\Console\Kernel as ConsoleKernel;
use Illuminate\Contracts\Foundation\Application;

/**
 * Class Kernel
 * @package App\Console
 */
class Kernel extends ConsoleKernel
{
    /**
     * The Artisan commands provided by your application.
     *
     * @var array
     */
    protected \$commands = [
    ];

    /**
     * Create a new console kernel instance.
     *
     * @param  Application  \$app
     */
    public function __construct(Application \$app)
    {
        if (class_exists('Laravelista\LumenVendorPublish\VendorPublishCommand')) {
            \$this->commands[] = 'Laravelista\LumenVendorPublish\VendorPublishCommand';
        }
        parent::__construct(\$app);
    }

    /**
     * Define the application's command schedule.
     *
     * @param  \Illuminate\Console\Scheduling\Schedule  \$schedule
     * @return void
     */
    protected function schedule(Schedule \$schedule)
    {
        //
    }
}
