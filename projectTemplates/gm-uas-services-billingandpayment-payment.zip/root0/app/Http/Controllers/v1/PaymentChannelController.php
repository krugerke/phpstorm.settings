<?php
/**
 * Created by IntelliJ IDEA.
 * User: qzd2d0
 * Date: 1/11/2017
 * Time: 9:10 AM
 */
namespace App\Http\Controllers\v1;

use App\Http\Controllers\Controller;
use App\PaymentChannel;
use GM\UAS\Core\Envelope\Http\Response;
use GM\UAS\Core\Envelope\Http\Validate;
use Illuminate\Http\Request;
use App\PaymentProcessor as Processor;
use GMLog;

/**
 * Class PaymentChannelController
 * @package App\Http\Controllers\v1
 */
class PaymentChannelController extends Controller
{
    /**
     * @var Response
     */
    protected \$response;

    /**
     * PaymentChannelController constructor.
     * @param Response \$response
     */
    public function __construct(Response \$response)
    {
        \$this->response = \$response;
    }

    /**
     * @param \$pid
     * @param null \$id
     * @return bool|\Illuminate\Http\Response
     */
    private function validateProcessorId(\$pid, \$id = null)
    {
        \$rules = [
            'processor' => 'required|alpha_dash|size:36|exists:payment_processor,guid',
        ];
        if (\$id !== null) {
            \$rules['id'] = 'required|alpha_dash|size:36|exists:payment_channel,guid';
        }
        if ((\$response = Validate::validate(\$this->response, ['processor' => \$pid, 'id' => \$id], \$rules)) !== true) {
            return \$response;
        }

        if (\$id !== null) {
            /** @var PaymentChannel \$channel */
            \$channel = PaymentChannel::query()->where('guid', '=', \$id)->first();
            if (\$channel->getProcessor()->getGUID() !== \$pid) {
                \$this->response->addCode(-1, 'Channel does not exist on processor');
                return \$this->response->badRequest();
            }
        }

        return true;
    }

    /**
     * @param \$pid
     * @return bool|\Illuminate\Http\Response
     */
    public function index(\$pid)
    {
        if ((\$response = \$this->validateProcessorId(\$pid)) !== true) {
            return \$response;
        }

        \$q = PaymentChannel::query();
        /** @var Processor \$processor */
        \$processor = Processor::query()->where('guid', '=', \$pid)->first();
        \$q->where('payment_processor_id', '=', \$processor->id);

        \$all = PaymentChannel::all();
        return \$this->response->index(\$all);
    }

    /**
     * @param \$pid
     * @param \$id
     * @return bool|\Illuminate\Http\Response
     */
    public function show(\$pid, \$id)
    {
        if ((\$response = \$this->validateProcessorId(\$pid, \$id)) !== true) {
            return \$response;
        }

        /** @var PaymentChannel \$channel */
        \$channel = PaymentChannel::query()->where('guid', '=', \$id)->first();
        return \$this->response->show(\$channel);
    }

    /**
     * @param Request \$request
     * @param \$pid
     * @return bool|\Illuminate\Http\Response
     */
    public function store(Request \$request, \$pid)
    {
        if ((\$response = \$this->validateProcessorId(\$pid)) !== true) {
            return \$response;
        }
        \$rules = [
            'name' => 'required|string',
            'channel' => 'required|string',
            'status' => 'required|in:'.implode(',', PaymentChannel::getStatuses()),
        ];
        if ((\$response = Validate::validate(\$this->response, \$request->all(), \$rules)) !== true) {
            return \$response;
        }

        \$processor = Processor::query()->where('guid', '=', \$pid)->first();

        \$channel = new PaymentChannel([
            'guid' => createGUID(),
            'payment_processor_id' => \$processor->id,
            'name' => \$request->get('name'),
            'channel' => \$request->get('channel'),
            'status' => \$request->get('status'),
        ]);

        try {
            \$channel->save();
        } catch (\Exception \$e) {
            GMLog::error(\$e->getMessage());
            return \$this->response->internalError();
        }

        return \$this->response->created(\$channel);
    }

    /**
     * @param Request \$request
     * @param \$pid
     * @param \$id
     * @return bool|\Illuminate\Http\Response
     */
    public function update(Request \$request, \$pid, \$id)
    {
        if ((\$response = \$this->validateProcessorId(\$pid, \$id)) !== true) {
            return \$response;
        }
        \$rules = [
            'name' => 'required|string',
            'channel' => 'required|string',
            'status' => 'required|in:'.implode(',', PaymentChannel::getStatuses()),
        ];
        if ((\$response = Validate::validate(\$this->response, \$request->all(), \$rules)) !== true) {
            return \$response;
        }

        \$processor = Processor::query()->where('guid', '=', \$pid)->first();

        /** @var PaymentChannel \$channel */
        \$channel = PaymentChannel::query()->where('guid', '=', \$id)->first();
        if (\$channel === null) {
            return \$this->response->notFoundError();
        }
        \$channel->update([
            'payment_processor_id' => \$processor->id,
            'name' => \$request->get('name'),
            'channel' => \$request->get('name'),
            'status' => \$request->get('status'),
        ]);
        try {
            \$channel->save();
        } catch (\Exception \$e) {
            GMLog::error(\$e->getMessage());
            \$this->response->internalError();
        }

        return \$this->response->updated(\$channel);
    }
}
