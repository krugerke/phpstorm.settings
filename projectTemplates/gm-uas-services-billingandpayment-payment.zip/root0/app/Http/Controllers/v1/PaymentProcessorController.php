<?php
/**
 * Created by IntelliJ IDEA.
 * User: QZD2D0
 * Date: 1/5/2017
 * Time: 10:39 AM
 */

namespace App\Http\Controllers\v1;

use App\Http\Controllers\Controller;
use App\PaymentProcessorCurrency;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use GM\UAS\Core\Envelope\Http\Response;
use GM\UAS\Core\Envelope\Http\Validate;
use Illuminate\Http\Request;
use App\PaymentProvider as Provider;
use App\PaymentProcessor as Processor;
use GMLog;

/**
 * Class PaymentProcessorController
 * @package App\Http\Controllers\v1
 */
class PaymentProcessorController extends Controller
{
    /**
     * @var Response
     */
    protected \$response;

    /**
     * PaymentProcessorController constructor.
     * @param Response \$response
     */
    public function __construct(Response \$response)
    {
        \$this->response = \$response;
    }

    /**
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        \$all = Processor::all();

        return \$this->response->index(\$all);
    }

    /**
     * @param \$id
     * @return bool|\Illuminate\Http\Response
     */
    public function show(\$id)
    {
        \$rules = [
            'id' => 'required|alpha_dash|size:36',
        ];
        if ((\$response = Validate::validate(\$this->response, ['id' => \$id], \$rules)) !== true) {
            return \$response;
        }

        /** @var Processor \$processor */
        \$processor = Processor::query()->where('guid', '=', \$id)->first();

        if (\$processor === null) {
            return \$this->response->notFoundError('Processor not found');
        }

        return \$this->response->show(\$processor);
    }

    /**
     * @param Request \$request
     * @return bool|\Illuminate\Http\Response
     */
    public function store(Request \$request)
    {
        \$rules = [
            'name' => 'required|string',
            'provider' => 'required|object_id|exists:payment_provider,guid',
            'username' => 'required|string',
            'password' => 'required|string',
            'sandbox' => 'boolean',
            'status' => 'required|integer|in:'.implode(',', Processor::getStatuses())
        ];
        if ((\$response = Validate::validate(\$this->response, \$request->all(), \$rules)) !== true) {
            return \$response;
        }

        /** @var Provider \$provider */
        \$provider = Provider::query()->where('guid', '=', \$request->get('provider')['id'])->first();

        if (\$provider === null) {
            \$this->response->addCode(-1, 'Provider not found');
            return \$this->response->badRequest();
        }

        \$processor = new Processor([
            'guid' => createGUID(),
            'name' => \$request->get('name'),
            'payment_provider_id' => \$provider->id,
            'sandbox' => \$request->get('sandbox') ? 1 : 0,
            'status' => \$request->get('status'),
        ]);
        try {
            \$processor->setUsername(\$request->get('username'));
            \$processor->setPassword(\$request->get('password'));
            \$processor->save();
        } catch (\Exception \$e) {
            GMLog::error(\$e->getMessage());
            return \$this->response->internalError();
        }

        return \$this->response->created(\$processor);
    }

    /**
     * @param Request \$request
     * @param \$id
     * @return bool|\Illuminate\Http\Response
     */
    public function update(Request \$request, \$id)
    {
        \$rules = [
            'name' => 'required|string',
            'provider' => 'required|object_id|exists:payment_provider,guid',
            'username' => 'required|string',
            'password' => 'required|string',
            'sandbox' => 'boolean',
        ];
        if ((\$response = Validate::validate(\$this->response, \$request->all(), \$rules)) !== true) {
            return \$response;
        }

        try {
            /** @var Processor \$processor */
            \$processor = Processor::query()->where('guid', '=', \$id)->firstOrFail();
        } catch (ModelNotFoundException \$e) {
            return \$this->response->notFoundError();
        }

        /** @var Provider \$provider */
        \$provider = Provider::query()->where('guid', '=', \$request->get('provider')['id'])->first();

        if (\$provider === null) {
            \$this->response->addCode(-1, 'Provider not found');
            return \$this->response->badRequest();
        }

        \$processor->update([
            'name' => \$request->get('name'),
            'payment_provider_id' => \$provider->id,
            'sandbox' => \$request->get('sandbox') ? 1 : 0,
        ]);
        try {
            \$processor->setUsername(\$request->get('username'));
            \$processor->setPassword(\$request->get('password'));
            \$processor->save();
        } catch (\Exception \$e) {
            GMLog::error(\$e->getMessage());
            return \$this->response->internalError();
        }

        return \$this->response->updated(\$processor);
    }

    /**
     * @param Request \$request
     * @param \$id
     * @return bool|\Illuminate\Http\Response
     */
    public function storeCurrency(Request \$request, \$id)
    {
        \$rules = [
            'iso_code' => 'required|alpha|size:3',
        ];
        if ((\$response = Validate::validate(\$this->response, \$request->all(), \$rules)) !== true) {
            return \$response;
        }

        /** @var Processor \$processor */
        \$processor = Processor::query()->where('guid', '=', \$id)->first();

        if (\$processor === null) {
            return \$this->response->notFoundError('Processor not found');
        }

        /** @var PaymentProcessorCurrency \$currency */
        foreach (\$processor->getCurrencies() as \$currency) {
            if (\$currency->iso_code === \$request->get('iso_code')) {
                \$this->response->addCode(-1, 'Currency already exists on processor');
                return \$this->response->badRequest();
            }
        }

        /** @var PaymentProcessorCurrency \$currency */
        \$currency = PaymentProcessorCurrency::query()->firstOrNew([
            'payment_processor_id' => \$processor->id,
            'iso_code' => \$request->get('iso_code'),
        ]);
        \$currency->save();

        return \$this->response->created(\$currency);
    }

    /**
     * @param Request \$request
     * @param \$id
     * @return bool|\Illuminate\Http\Response
     */
    public function destroyCurrency(Request \$request, \$id)
    {
        \$rules = [
            'iso_code' => 'required|alpha|size:3',
        ];
        if ((\$response = Validate::validate(\$this->response, \$request->all(), \$rules)) !== true) {
            return \$response;
        }

        /** @var Processor \$processor */
        \$processor = Processor::query()->where('guid', '=', \$id)->first();

        if (\$processor === null) {
            return \$this->response->notFoundError('Processor not found');
        }

        \$currency = PaymentProcessorCurrency::query()->where('payment_processor_id', '=', \$processor->id)
            ->where('iso_code', '=', \$request->get('iso_code'))->first();
        if (empty(\$currency)) {
            return \$this->response->notFoundError();
        }

        \$currency->delete();

        return \$this->response->deleted();
    }
}
