<?php
/**
 * Created by IntelliJ IDEA.
 * User: QZD2D0
 * Date: 1/9/2017
 * Time: 2:39 PM
 */

namespace App\Http\Controllers\v1;

use App\Http\Controllers\Controller;
use App\Exceptions\BadRequestException;
use App\Exceptions\PaymentFailedException;
use App\ProfileScript;
use App\Service\PaymentProfile;
use GM\UAS\Core\Envelope\Http\Response;
use GM\UAS\Core\Envelope\Http\Validate;
use Illuminate\Http\Request;
use GMLog;

/**
 * Class ProfileScriptController
 * @package App\Http\Controllers\v1
 */
class ProfileScriptController extends Controller
{
    /**
     * @var Response
     */
    protected \$response;

    /**
     * ProfileScriptController constructor.
     * @param Response \$response
     */
    public function __construct(Response \$response)
    {
        \$this->response = \$response;
    }

    /**
     * @param Request \$request
     * @return bool|\Illuminate\Http\Response
     */
    public function store(Request \$request)
    {
        \$rules = [
            'payment_channel' => 'required|object_id_any|exists:payment_channel,channel',
            'user' => 'required|object_id',
            'first_name' => 'string',
            'last_name' => 'string',
            'mobile' => 'string',
            'email' => 'string',
            'birth_date' => 'string',
            'time_on_file' => 'string',
            'driver_license' => 'string',
        ];
        if ((\$response = Validate::validate(\$this->response, \$request->all(), \$rules)) !== true) {
            return \$response;
        }

        try {
            \$paymentService = new PaymentProfile(\$request);

            /** @var ProfileScript \$profileScript */
            \$profileScript = \$paymentService->getProfileScript(\$request);
        } catch (BadRequestException \$e) {
            \$this->response->addCode(\$e->getCode(), \$e->getMessage());
            return \$this->response->badRequest();
        } catch (PaymentFailedException \$e) {
            GMLog::error(\$e->getMessage());
            return \$this->response->internalError();
        } catch (\Exception \$e) {
            GMLog::error(\$e->getMessage());
            return \$this->response->internalError();
        }

        return \$this->response->created(\$profileScript);
    }

    /**
     * @param Request \$request
     * @param \$id
     * @return bool|\Illuminate\Http\Response
     */
    public function status(Request \$request, \$id)
    {
        \$rules = [
            'id' => 'required|string',
        ];
        if ((\$response = Validate::validate(\$this->response, ['id' => \$id], \$rules)) !== true) {
            return \$response;
        }

        /** @var ProfileScript \$script */
        \$script = ProfileScript::query()->where('gateway_id', '=', \$id)->first();
        if (\$script === null) {
            return \$this->response->notFoundError();
        }

        try {
            \$paymentService = new PaymentProfile(\$request, \$script);

            /** @var ProfileScript \$profileScript */
            \$profileScript = \$paymentService->getProfileScriptStatus(\$request, \$id);
        } catch (BadRequestException \$e) {
            \$this->response->addCode(\$e->getCode(), \$e->getMessage());
            return \$this->response->badRequest();
        } catch (PaymentFailedException \$e) {
            GMLog::error(\$e->getMessage());
            return \$this->response->internalError();
        } catch (\Exception \$e) {
            GMLog::error(\$e->getMessage());
            return \$this->response->internalError();
        }

        return \$this->response->show(\$profileScript);
    }
}
