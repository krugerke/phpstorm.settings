<?php
/**
 * Created by IntelliJ IDEA.
 * User: QZD2D0
 * Date: 1/9/2017
 * Time: 9:42 AM
 */

namespace App\Http\Controllers\v1;

use App\Http\Controllers\Controller;
use App\Exceptions\BadRequestException;
use App\Exceptions\PaymentFailedException;
use App\Service\Payment;
use GM\UAS\Core\Envelope\Http\Response;
use GM\UAS\Core\Envelope\Http\Validate;
use Illuminate\Http\Request;
use App\Transaction;
use GMLog;

/**
 * Class TransactionController
 * @package App\Http\Controllers\v1
 */
class TransactionController extends Controller
{
    /**
     * @var Response
     */
    protected \$response;

    /**
     * TransactionController constructor.
     * @param Response \$response
     */
    public function __construct(Response \$response)
    {
        \$this->response = \$response;
    }

    /**
     * @param Request \$request
     * @return bool|\Illuminate\Http\Response
     */
    public function index(Request \$request)
    {
        \$rules = [
            'invoice' => 'object_id_any',
            'reservation' => 'object_id_any',
            'user' => 'object_id',
        ];
        if ((\$response = Validate::validate(\$this->response, \$request->all(), \$rules)) !== true) {
            return \$response;
        }

        \$q = Transaction::query();
        if (\$request->get('invoice')) {
            \$q->where('invoice', '=', \$request->get('invoice'));
        }
        if (\$request->get('reservation')) {
            \$q->where('reservation', '=', \$request->get('reservation'));
        }
        if (\$request->get('user')) {
            \$q->where('user_guid', '=', \$request->get('user')['id']);
        }
        try {
            \$transactions = \$q->get();
        } catch (\Exception \$e) {
            GMLog::error(\$e->getMessage());
            return \$this->response->internalError();
        }
        return \$this->response->index(\$transactions);
    }

    /**
     * @param Request \$request
     * @param \$id
     * @return bool|\Illuminate\Http\Response
     */
    public function show(Request \$request, \$id)
    {
        \$rules = [
            'id' => 'required|string',
        ];
        if ((\$response = Validate::validate(\$this->response, ['gateway_id' => \$id], \$rules)) !== true) {
            return \$response;
        }

        /** @var Transaction \$transaction */
        \$transaction = Transaction::query()->where('guid', '=', \$id)->first();
        if (\$transaction === null) {
            return \$this->response->notFoundError();
        }

        return \$this->response->show(\$transaction);
    }

    /**
     * @param Request \$request
     * @return bool|\Illuminate\Http\Response
     */
    public function store(Request \$request)
    {
        \$rules = [
            'profile' => 'required_without:user|object_id_any|exists:payment_profile,token',
            'user' => 'required_without:profile|object_id',
            'invoice' => 'object_id_any',
            'reservation' => 'object_id_any',
            'type' => 'required|string|in:'.implode(',', Transaction::listTypes()),
            'amount' => 'integer|min:1',
            'currency' => 'string|size:3',
            'descriptor' => 'string',
            'payment_channel' => 'object_id_any|exists:payment_channel,channel',
            'related_transaction' => 'object_id_any',
        ];
        if ((\$response = Validate::validate(\$this->response, \$request->all(), \$rules)) !== true) {
            return \$response;
        }

        try {
            \$paymentService = new Payment(\$request);

            /** @var Transaction \$transaction */
            \$transaction = \$paymentService->processTransaction(\$request);
        } catch (BadRequestException \$e) {
            \$this->response->addCode(\$e->getCode(), \$e->getMessage());
            return \$this->response->badRequest();
        } catch (PaymentFailedException \$e) {
            GMLog::error(\$e->getMessage());
            return \$this->response->internalError();
        } catch (\Exception \$e) {
            GMLog::error(\$e->getMessage());
            return \$this->response->internalError();
        }

        return \$this->response->created(\$transaction);
    }
}
