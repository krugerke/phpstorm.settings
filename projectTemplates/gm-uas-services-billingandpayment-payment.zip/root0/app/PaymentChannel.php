<?php
/**
 * Created by IntelliJ IDEA.
 * User: qzd2d0
 * Date: 1/11/2017
 * Time: 9:02 AM
 */

namespace App;

use GM\UAS\Core\Envelope\Contracts\Model\ModelObject;

/**
 * Class PaymentChannel
 * @package App
 * @SWG\Definition(
 *     definition="PaymentChannel",
 *     required={"id","processor","name","channel","status"}
 * )
 */
class PaymentChannel extends ModelObject
{
    /**
     *
     */
    const STATUS_INACTIVE = 0;
    /**
     *
     */
    const STATUS_ACTIVE = 1;

    /**
     * @return array
     */
    public static function getStatuses()
    {
        return [
            self::STATUS_INACTIVE,
            self::STATUS_ACTIVE,
        ];
    }

    /**
     * @var string
     */
    protected \$table = 'payment_channel';

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected \$fillable = [
        'id',
        'guid',
        'payment_processor_id',
        'name',
        'channel',
        'status',
        'created_at',
        'updated_at',
    ];

    /**
     * @SWG\Property(
     *   property="id", type="string", minLength=34, maxLength=34,
     *   pattern="^[0-9a-fA-F]{8}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{12}\$"
     * )
     * @SWG\Property(property="name", type="string")
     * @SWG\Property(property="processor", ref="\#/definitions/ObjectId")
     * @SWG\Property(property="status", type="integer")
     * @SWG\Property(property="channel", type="string")
     * @SWG\Property(property="created_at", ref="\#/definitions/DateTime"))
     * @SWG\Property(property="updated_at", ref="\#/definitions/DateTime"))
     * @return array
     */
    public function asData()
    {
        return [
            'id' => \$this->channel,
            'processor' => \$this->getProcessor()->asDataId(),
            'name' => \$this->name,
            'display_name' => \$this->getDisplayName(),
            'channel' => \$this->channel,
            'created_at' => \$this->created_at,
            'updated_at' => \$this->updated_at,
        ];
    }

    public function asDataId()
    {
        return [
            'id' => \$this->channel,
        ];
    }

    /**
     * @return string
     */
    public function getDisplayName()
    {
        return \$this->getProcessor()->getDisplayName() . ' :: ' . \$this->name;
    }

    /**
     * @return \App\PaymentProcessor
     */
    public function getProcessor()
    {
        /** @var \app\PaymentProcessor \$processor */
        \$processor = \$this->hasOne(PaymentProcessor::class, 'id', 'payment_processor_id')->getQuery()->first();
        return \$processor;
    }
}
