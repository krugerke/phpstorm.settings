<?php
/**
 * Created by IntelliJ IDEA.
 * User: QZD2D0
 * Date: 1/6/2017
 * Time: 4:50 PM
 */

namespace App;

use GM\UAS\Core\Envelope\Contracts\Model\ModelObject;

/**
 * Class PaymentProfile
 * @package App
 * @SWG\Definition(
 *     definition="PaymentProfile",
 *     required={"id","user","provider","token"}
 * )
 */
class PaymentProfile extends ModelObject
{
    /**
     * @var string
     */
    protected \$table = 'payment_profile';

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected \$fillable = [
        'id',
        'guid',
        'user_guid',
        'payment_provider_id',
        'token',
        'bin',
        'last4',
        'exp_month',
        'exp_year',
        'card_brand',
        'avs_response',
        'default',
        'created_at',
        'updated_at',
    ];

    /**
     * @SWG\Property(
     *   property="id", type="string", minLength=34, maxLength=34,
     *   pattern="^[0-9a-fA-F]{8}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{12}\$"
     * )
     * @SWG\Property(property="user", ref="\#/definitions/ObjectId")
     * @SWG\Property(property="provider", ref="\#/definitions/ObjectId")
     * @SWG\Property(property="default", type="boolean")
     * @SWG\Property(property="token", type="string")
     * @SWG\Property(property="bin", type="string")
     * @SWG\Property(property="last4", type="string")
     * @SWG\Property(property="exp_month", type="string")
     * @SWG\Property(property="exp_year", type="string")
     * @SWG\Property(property="card_brand", type="string")
     * @SWG\Property(property="avs_response", type="string")
     * @SWG\Property(property="created_at", ref="\#/definitions/DateTime"))
     * @SWG\Property(property="updated_at", ref="\#/definitions/DateTime"))
     * @return array
     */
    public function asData()
    {
        return [
            'id' => \$this->token,
            'provider' => \$this->getProvider()->asDataId(),
            'user' => ['id' => \$this->user_guid],
            'token' => \$this->token,
            'bin' => \$this->bin,
            'last4' => \$this->last4,
            'exp_month' => \$this->exp_month,
            'exp_year' => \$this->exp_year,
            'card_brand' => \$this->card_brand,
            'avs_response' => \$this->avs_response,
            'default' => \$this->default,
            'created_at' => \$this->created_at,
            'updated_at' => \$this->updated_at,
        ];
    }

    public function asDataId()
    {
        return [
            'id' => \$this->token,
        ];
    }

    /**
     * @return \App\PaymentProvider
     */
    public function getProvider()
    {
        /** @var \App\PaymentProvider \$provider */
        \$provider = \$this->hasOne(PaymentProvider::class, 'id', 'payment_provider_id')->getQuery()->first();
        return \$provider;
    }
}
