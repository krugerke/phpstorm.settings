<?php
/**
 * Created by IntelliJ IDEA.
 * User: QZD2D0
 * Date: 1/9/2017
 * Time: 12:05 PM
 */
namespace App\PaymentProvider;

use App\Exceptions\BadRequestException;
use App\PaymentChannel;
use App\PaymentProcessor;
use App\PaymentProfile;
use App\ProfileScript;
use App\Transaction;
use Illuminate\Http\Request;

/**
 * Interface PaymentProviderInterface
 * @package App\PaymentProvider
 */
interface PaymentProviderInterface
{
    /**
     * PaymentProviderInterface constructor.
     * @param PaymentProcessor \$processor
     * @param PaymentChannel \$channel
     * @param PaymentProfile \$profile
     */
    public function __construct(
        PaymentProcessor \$processor,
        PaymentChannel \$channel = null,
        PaymentProfile \$profile = null
    );

    /**
     * @param Request \$request
     * @return Transaction
     * @throws \Exception
     * @throws BadRequestException
     */
    public function auth(Request \$request);

    /**
     * @param Request \$request
     * @return Transaction
     * @throws \Exception
     * @throws BadRequestException
     */
    public function cap(Request \$request);

    /**
     * @param Request \$request
     * @return Transaction
     * @throws \Exception
     * @throws BadRequestException
     */
    public function authcap(Request \$request);

    /**
     * @param Request \$request
     * @return Transaction
     * @throws \Exception
     * @throws BadRequestException
     */
    public function void(Request \$request);

    /**
     * @param Request \$request
     * @return Transaction
     * @throws \Exception
     * @throws BadRequestException
     */
    public function refund(Request \$request);

    /**
     * @param Request \$request
     * @return Transaction
     * @throws \Exception
     * @throws BadRequestException
     */
    public function credit(Request \$request);

    /**
     * @param Request \$request
     * @return ProfileScript
     * @throws \Exception
     * @throws BadRequestException
     */
    public function profileScript(Request \$request);

    /**
     * @param Request \$request
     * @param \$id
     * @return ProfileScript
     * @throws \Exception
     * @throws BadRequestException
     */
    public function profileScriptStatus(Request \$request, \$id);
}
