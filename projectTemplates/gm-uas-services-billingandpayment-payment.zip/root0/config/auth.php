<?php
/**
 * Created by IntelliJ IDEA.
 * User: QZD2D0
 * Date: 1/30/2017
 * Time: 5:01 PM
 */

return [
    'model' => \GM\UAS\Core\Authenticate\User::class,
    'driver' => 'eloquent',
    'table' => 'users',
    'password' => [
        'email' => 'emails.password',
        'table' => 'password_resets',
        'expire' => 60,
    ]
];
