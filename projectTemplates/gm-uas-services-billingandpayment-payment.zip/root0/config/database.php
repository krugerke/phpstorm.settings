<?php

return [
    'fetch' => PDO::FETCH_CLASS,
    'default' => env('DB_CONNECTION', 'sqlite'),
    'connections' => [
        'sqlite_test' => array(
            'driver' => 'sqlite',
            'database' => ':memory:',
            'prefix' => '',
        ),
        'oracle' => array(
            'driver'        => 'oracle',
            'host'          => isset(\$_ENV['CREDENTIALS']['ORACLE_BILLINGANDPAYMENT']['DB_HOST'])
                ? \$_ENV['CREDENTIALS']['ORACLE_BILLINGANDPAYMENT']['DB_HOST'] : env('DB_HOST', '127.0.0.1'),
            'port'          => isset(\$_ENV['CREDENTIALS']['ORACLE_BILLINGANDPAYMENT']['DB_PORT'])
                ? \$_ENV['CREDENTIALS']['ORACLE_BILLINGANDPAYMENT']['DB_PORT'] : env('DB_PORT', 1521),
            'database'      => isset(\$_ENV['CREDENTIALS']['ORACLE_BILLINGANDPAYMENT']['DB_DATABASE'])
                ? \$_ENV['CREDENTIALS']['ORACLE_BILLINGANDPAYMENT']['DB_DATABASE'] : env('DB_DATABASE', ''),
            'username'      => isset(\$_ENV['CREDENTIALS']['ORACLE_BILLINGANDPAYMENT']['DB_USERNAME'])
                ? \$_ENV['CREDENTIALS']['ORACLE_BILLINGANDPAYMENT']['DB_USERNAME'] : env('DB_USERNAME', ''),
            'password'      => isset(\$_ENV['CREDENTIALS']['ORACLE_BILLINGANDPAYMENT']['DB_PASSWORD'])
                ? \$_ENV['CREDENTIALS']['ORACLE_BILLINGANDPAYMENT']['DB_PASSWORD'] : env('DB_PASSWORD', ''),
            'service_name'  => isset(\$_ENV['CREDENTIALS']['ORACLE_BILLINGANDPAYMENT']['DB_SERVICE_NAME'])
                ? \$_ENV['CREDENTIALS']['ORACLE_BILLINGANDPAYMENT']['DB_SERVICE_NAME'] : env('DB_SERVICE_NAME', ''),
            'charset'       => env('DB_CHARSET', 'AL32UTF8'),
            'prefix'        => env('DB_PREFIX', ''),
            'prefix_schema' => env('DB_SCHEMA_PREFIX', ''),
        ),
        'api_log' => array(
            'driver'        => 'oracle',
            'host'          => isset(\$_ENV['CREDENTIALS']['ORACLE_BILLINGANDPAYMENT']['DB_HOST'])
                ? \$_ENV['CREDENTIALS']['ORACLE_BILLINGANDPAYMENT']['DB_HOST'] : env('DB_HOST', '127.0.0.1'),
            'port'          => isset(\$_ENV['CREDENTIALS']['ORACLE_BILLINGANDPAYMENT']['DB_PORT'])
                ? \$_ENV['CREDENTIALS']['ORACLE_BILLINGANDPAYMENT']['DB_PORT'] : env('DB_PORT', 1521),
            'database'      => isset(\$_ENV['CREDENTIALS']['ORACLE_BILLINGANDPAYMENT']['DB_DATABASE'])
                ? \$_ENV['CREDENTIALS']['ORACLE_BILLINGANDPAYMENT']['DB_DATABASE'] : env('DB_DATABASE', ''),
            'username'      => isset(\$_ENV['CREDENTIALS']['ORACLE_BILLINGANDPAYMENT']['DB_USERNAME'])
                ? \$_ENV['CREDENTIALS']['ORACLE_BILLINGANDPAYMENT']['DB_USERNAME'] : env('DB_USERNAME', ''),
            'password'      => isset(\$_ENV['CREDENTIALS']['ORACLE_BILLINGANDPAYMENT']['DB_PASSWORD'])
                ? \$_ENV['CREDENTIALS']['ORACLE_BILLINGANDPAYMENT']['DB_PASSWORD'] : env('DB_PASSWORD', ''),
            'service_name'  => isset(\$_ENV['CREDENTIALS']['ORACLE_BILLINGANDPAYMENT']['DB_SERVICE_NAME'])
                ? \$_ENV['CREDENTIALS']['ORACLE_BILLINGANDPAYMENT']['DB_SERVICE_NAME'] : env('DB_SERVICE_NAME', ''),
            'charset'       => env('DB_CHARSET', 'AL32UTF8'),
            'prefix'        => env('DB_PREFIX', ''),
            'prefix_schema' => env('DB_SCHEMA_PREFIX', ''),
        ),
        'error_log' => array(
            'driver'        => 'oracle',
            'host'          => isset(\$_ENV['CREDENTIALS']['ORACLE_BILLINGANDPAYMENT']['DB_HOST'])
                ? \$_ENV['CREDENTIALS']['ORACLE_BILLINGANDPAYMENT']['DB_HOST'] : env('DB_HOST', '127.0.0.1'),
            'port'          => isset(\$_ENV['CREDENTIALS']['ORACLE_BILLINGANDPAYMENT']['DB_PORT'])
                ? \$_ENV['CREDENTIALS']['ORACLE_BILLINGANDPAYMENT']['DB_PORT'] : env('DB_PORT', 1521),
            'database'      => isset(\$_ENV['CREDENTIALS']['ORACLE_BILLINGANDPAYMENT']['DB_DATABASE'])
                ? \$_ENV['CREDENTIALS']['ORACLE_BILLINGANDPAYMENT']['DB_DATABASE'] : env('DB_DATABASE', ''),
            'username'      => isset(\$_ENV['CREDENTIALS']['ORACLE_BILLINGANDPAYMENT']['DB_USERNAME'])
                ? \$_ENV['CREDENTIALS']['ORACLE_BILLINGANDPAYMENT']['DB_USERNAME'] : env('DB_USERNAME', ''),
            'password'      => isset(\$_ENV['CREDENTIALS']['ORACLE_BILLINGANDPAYMENT']['DB_PASSWORD'])
                ? \$_ENV['CREDENTIALS']['ORACLE_BILLINGANDPAYMENT']['DB_PASSWORD'] : env('DB_PASSWORD', ''),
            'service_name'  => isset(\$_ENV['CREDENTIALS']['ORACLE_BILLINGANDPAYMENT']['DB_SERVICE_NAME'])
                ? \$_ENV['CREDENTIALS']['ORACLE_BILLINGANDPAYMENT']['DB_SERVICE_NAME'] : env('DB_SERVICE_NAME', ''),
            'charset'       => env('DB_CHARSET', 'AL32UTF8'),
            'prefix'        => env('DB_PREFIX', ''),
            'prefix_schema' => env('DB_SCHEMA_PREFIX', ''),
        ),

        'mysql' => [
            'driver'    => 'mysql',
            'host'      => env('DB_HOST', 'localhost'),
            'database'  => env('DB_DATABASE', 'forge'),
            'username'  => env('DB_USERNAME', 'forge'),
            'password'  => env('DB_PASSWORD', ''),
            'charset'   => 'utf8',
            'collation' => 'utf8_unicode_ci',
            'prefix'    => '',
            'strict'    => false,
        ],

        'pgsql' => [
            'driver'   => 'pgsql',
            'host'     => env('DB_HOST', 'localhost'),
            'database' => env('DB_DATABASE', 'forge'),
            'username' => env('DB_USERNAME', 'forge'),
            'password' => env('DB_PASSWORD', ''),
            'charset'  => 'utf8',
            'prefix'   => '',
            'schema'   => 'public',
        ],

        'sqlsrv' => [
            'driver'   => 'sqlsrv',
            'host'     => env('DB_HOST', 'localhost'),
            'database' => env('DB_DATABASE', 'forge'),
            'username' => env('DB_USERNAME', 'forge'),
            'password' => env('DB_PASSWORD', ''),
            'charset'  => 'utf8',
            'prefix'   => '',
        ],

    ],

    /*
    |--------------------------------------------------------------------------
    | Migration Repository Table
    |--------------------------------------------------------------------------
    |
    | This table keeps track of all the migrations that have already run for
    | your application. Using this information, we can determine which of
    | the migrations on disk haven't actually been run in the database.
    |
    */

    'migrations' => 'migrations',

    /*
    |--------------------------------------------------------------------------
    | Redis Databases
    |--------------------------------------------------------------------------
    |
    | Redis is an open source, fast, and advanced key-value store that also
    | provides a richer set of commands than a typical key-value systems
    | such as APC or Memcached. Laravel makes it easy to dig right in.
    |
    */

    'redis' => [

        'cluster' => false,

        'default' => [
            'host'     => isset(\$_ENV['CREDENTIALS']['REDIS']['REDIS_HOST'])
                ? \$_ENV['CREDENTIALS']['REDIS']['REDIS_HOST'] : env('REDIS_HOST', 'localhost'),
            'port'     => isset(\$_ENV['CREDENTIALS']['REDIS']['REDIS_PORT'])
                ? \$_ENV['CREDENTIALS']['REDIS']['REDIS_PORT'] :env('REDIS_PORT', ''),
            'password' => isset(\$_ENV['CREDENTIALS']['REDIS']['REDIS_PASSWORD'])
                ? \$_ENV['CREDENTIALS']['REDIS']['REDIS_PASSWORD'] : env('REDIS_PASSWORD', ''),
            'database' => isset(\$_ENV['CREDENTIALS']['REDIS']['REDIS_DATABASE'])
                ? \$_ENV['CREDENTIALS']['REDIS']['REDIS_DATABASE'] : env('REDIS_DATABASE', 0)
        ],

    ],

];
