<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreatePaymentProcessorTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('payment_processor', function (Blueprint \$table) {
            \$table->increments('id');
            \$table->string('guid', 36);
            \$table->string('name', 64);
            \$table->integer('payment_provider_id', false, true);
            \$table->string('username', 1024);
            \$table->string('password', 1024);
            \$table->integer('status')->unsigned();
            \$table->boolean('sandbox');
            \$table->timestamps();
            \$table->unique(['guid']);
            \$table->foreign('payment_provider_id')->references('id')->on('payment_provider');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::drop('payment_processor');
    }
}
