<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreatePaymentProcessorCurrencyTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('payment_processor_currency', function (Blueprint \$table) {
            \$table->increments('id');
            \$table->integer('payment_processor_id', false, true);
            \$table->string('iso_code', 3);
            \$table->timestamps();

            \$table->foreign('payment_processor_id')->references('id')->on('payment_processor');
            \$table->unique(['payment_processor_id', 'iso_code'], 'uniq_payment_processor_iso');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::drop('payment_processor_currency', function (Blueprint \$table) {
            //
        });
    }
}
