<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreatePaymentChannelTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('payment_channel', function (Blueprint \$table) {
            \$table->increments('id');
            \$table->string('guid', 36);
            \$table->integer('payment_processor_id')->unsigned();
            \$table->string('name');
            \$table->string('channel')->unique();
            \$table->integer('status')->unsigned();
            \$table->unique('guid');
            \$table->foreign('payment_processor_id')->references('id')->on('payment_processor');
            \$table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::drop('payment_channel');
    }
}
