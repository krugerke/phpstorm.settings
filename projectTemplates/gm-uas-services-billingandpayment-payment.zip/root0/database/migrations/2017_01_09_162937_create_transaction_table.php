<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateTransactionTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('payment_transaction', function (Blueprint \$table) {
            \$table->increments('id');
            \$table->string('guid', 36);
            \$table->string('user_guid', 36);
            \$table->integer('payment_profile_id')->unsigned();
            \$table->string('invoice')->nullable();
            \$table->string('reservation')->nullable();
            \$table->string('type', 16);
            \$table->integer('amount')->nullable();
            \$table->char('currency', 3)->nullable();
            \$table->string('descriptor')->nullable();
            \$table->integer('status');
            \$table->string('gateway_id')->nullable();
            \$table->string('gateway_resp_code')->nullable();
            \$table->string('gateway_resp_message')->nullable();
            \$table->integer('payment_channel_id')->unsigned()->nullable();
            \$table->integer('related_transaction_id')->unsigned()->nullable();
            \$table->string('avs_response', 16)->nullable();
            \$table->timestamps();
            \$table->unique(['guid']);
            \$table->foreign('payment_profile_id')->references('id')->on('payment_profile');
            \$table->foreign('payment_channel_id')->references('id')->on('payment_channel');
            \$table->foreign('related_transaction_id')->references('id')->on('payment_transaction');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::drop('payment_transaction', function (Blueprint \$table) {
            //
        });
    }
}
