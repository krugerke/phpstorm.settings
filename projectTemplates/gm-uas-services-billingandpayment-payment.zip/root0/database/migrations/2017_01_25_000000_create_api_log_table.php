<?php
/**
 * Created by IntelliJ IDEA.
 * User: qzd2d0
 * Date: 1/24/2017
 * Time: 4:58 PM
 */

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateApiLogTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::connection('api_log')->create('api_log', function (Blueprint \$table) {
            \$table->increments('id');
            \$table->string('service');
            \$table->string('method', 8);
            \$table->string('route');
            \$table->string('requested_by')->nullable();
            \$table->string('ip', 32)->nullable();
            \$table->text('request_header')->nullable();
            \$table->text('request_body')->nullable();
            \$table->string('response_status', 8);
            \$table->text('response_body')->nullable();
            \$table->string('user_agent')->nullable();
            \$table->timestamp('requested_at');
            \$table->timestamp('responded_at');
            \$table->string('vcap_request_id')->nullable();
            \$table->timestamps();
            \$table->index(['service']);
            \$table->index(['route']);
            \$table->index(['response_status']);
            \$table->index(['requested_at']);
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::connection('api_log')->drop('api_log');
    }
}
